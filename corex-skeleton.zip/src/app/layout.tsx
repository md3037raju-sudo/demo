import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import { ThemeProvider } from 'next-themes';
import "./globals.css";
import { Toaster } from "@/components/ui/sonner";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  viewportFit: "cover",
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#f5faf7" },
    { media: "(prefers-color-scheme: dark)", color: "#0d1a14" },
  ],
};

export const metadata: Metadata = {
  title: "CoreX — Fast & Secure Proxy Platform",
  description: "CoreX provides fast and secure proxy subscriptions. Connect with VLESS, VMess, Trojan, Shadowsocks and more through our Clash-powered app.",
  keywords: ["CoreX", "Proxy", "VPN", "Clash", "VLESS", "VMess", "Trojan", "Shadowsocks"],
  authors: [{ name: "CoreX Team" }],
  icons: {
    icon: "/favicon.ico",
  },
  openGraph: {
    title: "CoreX — Fast & Secure Proxy Platform",
    description: "Fast and secure proxy subscriptions powered by Clash",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground touch-manipulation`}
        style={{ WebkitTapHighlightColor: 'transparent' }}
      >
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem disableTransitionOnChange>
          {children}
        </ThemeProvider>
        <Toaster />
      </body>
    </html>
  );
}
