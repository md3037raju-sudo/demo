'use client'

import { useState, createContext, useContext, useCallback, type ReactNode } from 'react'
import { LandingPage } from '@/components/pages/landing-page'
import { LoginPage } from '@/components/pages/login-page'
import { AboutPage } from '@/components/pages/about-page'
import { DashboardLayout } from '@/components/dashboard/dashboard-layout'
import { AdminLayout } from '@/components/admin/admin-layout'
import { DownloadPage } from '@/components/pages/download-page'
import { DocsPage } from '@/components/pages/docs-page'

// ── Types ──────────────────────────────────────────────────────────────

export type Page =
  | 'landing'
  | 'login'
  | 'about'
  | 'download'
  | 'docs'
  | 'dashboard'
  | 'dashboard/subscriptions'
  | 'dashboard/activedevices'
  | 'dashboard/payments'
  | 'dashboard/referrals'
  | 'dashboard/themes'
  | 'dashboard/tickets'
  | 'dashboard/settings'
  | 'admin'
  | 'admin/dashboard'
  | 'admin/users'
  | 'admin/subscriptions'
  | 'admin/plans'
  | 'admin/payments'
  | 'admin/coupons'
  | 'admin/tickets'
  | 'admin/rules'
  | 'admin/proxies'
  | 'admin/devices'
  | 'admin/broadcast'
  | 'admin/utility'
  | 'admin/cms'
  | 'admin/2fa'
  | 'admin/logs'

export interface AppUser {
  id: string
  name: string
  email: string
  avatar: string
  role: 'user' | 'admin'
  balance: number
}

export interface AppContextType {
  currentPage: Page
  navigate: (page: Page) => void
  isAuthenticated: boolean
  user: AppUser | null
  login: (role?: 'user' | 'admin') => void
  logout: () => void
}

// ── Context ────────────────────────────────────────────────────────────

export const AppContext = createContext<AppContextType | null>(null)

export function useApp(): AppContextType {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp must be used inside <AppProvider>')
  return ctx
}

// ── Provider ───────────────────────────────────────────────────────────

const MOCK_USERS: Record<'user' | 'admin', AppUser> = {
  user: {
    id: 'usr_1',
    name: 'Demo User',
    email: 'user@corex.dev',
    avatar: '',
    role: 'user',
    balance: 25.0,
  },
  admin: {
    id: 'adm_1',
    name: 'Admin',
    email: 'admin@corex.dev',
    avatar: '',
    role: 'admin',
    balance: 0,
  },
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [currentPage, setCurrentPage] = useState<Page>('landing')
  const [user, setUser] = useState<AppUser | null>(null)

  const isAuthenticated = user !== null

  const navigate = useCallback((page: Page) => {
    setCurrentPage(page)
  }, [])

  const login = useCallback((role: 'user' | 'admin' = 'user') => {
    setUser(MOCK_USERS[role])
  }, [])

  const logout = useCallback(() => {
    setUser(null)
    setCurrentPage('landing')
  }, [])

  return (
    <AppContext.Provider
      value={{ currentPage, navigate, isAuthenticated, user, login, logout }}
    >
      {children}
    </AppContext.Provider>
  )
}

// ── Router ─────────────────────────────────────────────────────────────

function Router() {
  const { currentPage, isAuthenticated, user } = useApp()

  // Admin pages — require admin role
  if (currentPage.startsWith('admin')) {
    if (!isAuthenticated || user?.role !== 'admin') return <LoginPage />
    return <AdminLayout />
  }

  // Public pages
  if (currentPage === 'landing') return <LandingPage />
  if (currentPage === 'login') return <LoginPage />
  if (currentPage === 'about') return <AboutPage />

  // Auth-only pages
  if (currentPage === 'download') {
    if (!isAuthenticated) return <LoginPage />
    return <DownloadPage />
  }
  if (currentPage === 'docs') {
    if (!isAuthenticated) return <LoginPage />
    return <DocsPage />
  }

  // Dashboard pages (all auth-required)
  if (!isAuthenticated) return <LoginPage />
  return <DashboardLayout />
}

// ── Page Entry ─────────────────────────────────────────────────────────

export default function Home() {
  return (
    <AppProvider>
      <Router />
    </AppProvider>
  )
}
