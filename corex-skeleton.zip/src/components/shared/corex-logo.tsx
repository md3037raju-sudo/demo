'use client'

import Image from 'next/image'
import { useTheme } from 'next-themes'

interface CoreXLogoProps {
  height?: number
  className?: string
  showAdminBadge?: boolean
  showText?: boolean
  animate?: boolean
}

export function CoreXLogo({
  height = 32,
  className = '',
  showAdminBadge = false,
  showText = true,
  animate = false,
}: CoreXLogoProps) {
  const { resolvedTheme } = useTheme()

  const logoSrc = resolvedTheme === 'dark'
    ? '/corex-logo-dark.png'
    : '/corex-logo-light.png'

  const width = height

  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <div className={`relative ${animate ? 'thunder-glow' : ''}`}>
        <Image
          src={logoSrc}
          alt="CoreX Logo"
          width={width}
          height={height}
          className="object-contain"
          priority
        />
        {animate && (
          <div className="absolute inset-0 rounded-full thunder-flash pointer-events-none" />
        )}
      </div>
      {showText && (
        <span className="font-bold tracking-tight" style={{ fontSize: `${Math.max(14, height * 0.65)}px` }}>
          Core<span className="text-primary">X</span>
        </span>
      )}
      {showAdminBadge && (
        <span className="ml-1 rounded-md bg-red-500/20 border border-red-500/30 px-2 py-0.5 text-[10px] font-medium text-red-400">
          Admin
        </span>
      )}
    </div>
  )
}

export function CoreXLogoIcon({ size = 32, className = '', animate = false }: { size?: number; className?: string; animate?: boolean }) {
  const { resolvedTheme } = useTheme()

  const logoSrc = resolvedTheme === 'dark'
    ? '/corex-logo-dark.png'
    : '/corex-logo-light.png'

  return (
    <div className={`relative ${animate ? 'thunder-glow' : ''}`}>
      <Image
        src={logoSrc}
        alt="CoreX"
        width={size}
        height={size}
        className={`object-contain ${className}`}
        priority
      />
      {animate && (
        <div className="absolute inset-0 rounded-full thunder-flash pointer-events-none" />
      )}
    </div>
  )
}
