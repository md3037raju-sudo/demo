'use client'

import React, { useEffect, useState } from 'react'

type AnimationType = 'fade-in' | 'slide-up' | 'scale-in' | 'slide-right'

interface AnimateInProps {
  children: React.ReactNode
  type?: AnimationType
  delay?: number
  stagger?: boolean
  className?: string
}

/**
 * Wraps children with entrance animation when animations are enabled.
 * Checks if <html> has the "animate-enabled" class.
 * When animations are OFF, children render instantly with no animation.
 */
export function AnimateIn({ children, type = 'slide-up', delay, stagger, className = '' }: AnimateInProps) {
  const [enabled, setEnabled] = useState(false)

  useEffect(() => {
    const check = () => setEnabled(document.documentElement.classList.contains('animate-enabled'))
    check()
    const observer = new MutationObserver(check)
    observer.observe(document.documentElement, { attributes: true, attributeFilter: ['class'] })
    return () => observer.disconnect()
  }, [])

  const animClass = enabled ? `anim-${type}` : ''
  const staggerClass = stagger && enabled ? 'anim-stagger' : ''
  const delayStyle = delay && enabled ? { animationDelay: `${delay}ms` } : undefined

  return (
    <div className={`${animClass} ${staggerClass} ${className}`.trim()} style={delayStyle}>
      {children}
    </div>
  )
}
