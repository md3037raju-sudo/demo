'use client'

import React, { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { Smartphone, Monitor, Globe, Trash2, Wifi, WifiOff } from 'lucide-react'
import { toast } from 'sonner'

interface Device {
  id: string
  name: string
  type: 'mobile' | 'desktop'
  os: string
  ip: string
  location: string
  lastActive: string
  status: 'online' | 'offline'
  user: string
}

const staticDevices: Device[] = [
  {
    id: 'dev_001',
    name: 'Samsung Galaxy S24',
    type: 'mobile',
    os: 'Android 14',
    ip: '103.45.67.89',
    location: 'Dhaka, Bangladesh',
    lastActive: '2025-02-12 14:30',
    status: 'online',
    user: 'Rahim Ahmed',
  },
  {
    id: 'dev_002',
    name: 'iPhone 15 Pro',
    type: 'mobile',
    os: 'iOS 17.3',
    ip: '45.33.21.56',
    location: 'Chittagong, Bangladesh',
    lastActive: '2025-02-12 13:15',
    status: 'online',
    user: 'Karim Hassan',
  },
  {
    id: 'dev_003',
    name: 'MacBook Pro M3',
    type: 'desktop',
    os: 'macOS 14.2',
    ip: '78.12.45.90',
    location: 'Sylhet, Bangladesh',
    lastActive: '2025-02-11 22:00',
    status: 'offline',
    user: 'Fatima Begum',
  },
  {
    id: 'dev_004',
    name: 'Xiaomi Redmi Note 13',
    type: 'mobile',
    os: 'Android 13',
    ip: '112.67.89.34',
    location: 'Rajshahi, Bangladesh',
    lastActive: '2025-02-12 10:45',
    status: 'online',
    user: 'Nasir Uddin',
  },
  {
    id: 'dev_005',
    name: 'Windows PC',
    type: 'desktop',
    os: 'Windows 11',
    ip: '89.56.12.78',
    location: 'Khulna, Bangladesh',
    lastActive: '2025-02-10 18:30',
    status: 'offline',
    user: 'Sabrina Akter',
  },
  {
    id: 'dev_006',
    name: 'iPad Air M2',
    type: 'mobile',
    os: 'iPadOS 17.3',
    ip: '56.78.90.12',
    location: 'Comilla, Bangladesh',
    lastActive: '2025-02-12 12:00',
    status: 'online',
    user: 'Arif Rahman',
  },
]

export function AdminDevices() {
  const [devices, setDevices] = useState<Device[]>(staticDevices)

  const handleRemoveDevice = (id: string) => {
    setDevices((prev) => prev.filter((d) => d.id !== id))
    toast.success('Device removed successfully')
  }

  const onlineCount = devices.filter((d) => d.status === 'online').length
  const offlineCount = devices.filter((d) => d.status === 'offline').length
  const mobileCount = devices.filter((d) => d.type === 'mobile').length
  const desktopCount = devices.filter((d) => d.type === 'desktop').length

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Device Management</h2>
        <p className="text-muted-foreground text-sm mt-1">Monitor and manage connected devices</p>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card className="border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex size-10 items-center justify-center rounded-lg bg-primary/15">
                <Smartphone className="size-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{devices.length}</p>
                <p className="text-xs text-muted-foreground">Total Devices</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex size-10 items-center justify-center rounded-lg bg-emerald-500/15">
                <Wifi className="size-5 text-emerald-400" />
              </div>
              <div>
                <p className="text-2xl font-bold">{onlineCount}</p>
                <p className="text-xs text-muted-foreground">Online</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex size-10 items-center justify-center rounded-lg bg-red-500/15">
                <WifiOff className="size-5 text-red-400" />
              </div>
              <div>
                <p className="text-2xl font-bold">{offlineCount}</p>
                <p className="text-xs text-muted-foreground">Offline</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex size-10 items-center justify-center rounded-lg bg-muted/50">
                <Monitor className="size-5 text-muted-foreground" />
              </div>
              <div>
                <p className="text-2xl font-bold">{desktopCount} / {mobileCount}</p>
                <p className="text-xs text-muted-foreground">Desktop / Mobile</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Device Table */}
      <Card>
        <CardHeader>
          <CardTitle>Connected Devices</CardTitle>
          <CardDescription>All devices currently linked to user accounts</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Device</TableHead>
                  <TableHead>User</TableHead>
                  <TableHead>OS</TableHead>
                  <TableHead>IP Address</TableHead>
                  <TableHead>Location</TableHead>
                  <TableHead>Last Active</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {devices.map((device) => (
                  <TableRow key={device.id}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {device.type === 'mobile' ? (
                          <Smartphone className="size-4 text-muted-foreground" />
                        ) : (
                          <Monitor className="size-4 text-muted-foreground" />
                        )}
                        <span className="font-medium">{device.name}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-sm">{device.user}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">{device.os}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1.5">
                        <Globe className="size-3 text-muted-foreground" />
                        <code className="text-xs font-mono">{device.ip}</code>
                      </div>
                    </TableCell>
                    <TableCell className="text-sm">{device.location}</TableCell>
                    <TableCell className="text-sm text-muted-foreground whitespace-nowrap">{device.lastActive}</TableCell>
                    <TableCell>
                      {device.status === 'online' ? (
                        <Badge className="bg-emerald-500/15 text-emerald-400 border-emerald-500/30">Online</Badge>
                      ) : (
                        <Badge variant="secondary">Offline</Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive">
                            <Trash2 className="size-3.5" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Remove Device</AlertDialogTitle>
                            <AlertDialogDescription>
                              Are you sure you want to remove &quot;{device.name}&quot;? The user will need to re-authenticate on this device.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={() => handleRemoveDevice(device.id)}>
                              Remove
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </TableCell>
                  </TableRow>
                ))}
                {devices.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center text-muted-foreground py-8">
                      No devices found
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
