'use client'

import { useState, useCallback, useMemo } from 'react'
import { toast } from 'sonner'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Textarea } from '@/components/ui/textarea'
import { Separator } from '@/components/ui/separator'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Plus,
  ArrowLeft,
  Pencil,
  Trash2,
  Activity,
  ChevronDown,
  ChevronRight,
  Upload,
  ImagePlus,
  HeartPulse,
  Server,
  Users,
  Globe,
  ShieldCheck,
  Copy,
} from 'lucide-react'

// ─── Types ───────────────────────────────────────────────────────────

type ProxyProtocol = 'vless' | 'vmess' | 'trojan' | 'ss' | 'ssr' | 'wireguard' | 'socks5' | 'http'

interface ProxyEntry {
  id: string
  protocol: ProxyProtocol
  address: string
  port: number
  uuid?: string
  password?: string
  username?: string
  flow?: string
  network?: string
  tls?: boolean
  sni?: string
  alpn?: string
  cipher?: string
  alterId?: number
  skipCertVerify?: boolean
  realityPublicKey?: string
  realityShortId?: string
  clientFingerprint?: string
  grpcService?: string
  wsPath?: string
  wsHost?: string
  udp?: boolean
  plugin?: string
  pluginOptsMode?: string
  pluginOptsHost?: string
  ssrProtocol?: string
  obfs?: string
  obfsParam?: string
  privateKey?: string
  publicKey?: string
  presharedKey?: string
  dns?: string
  mtu?: number
  status: 'online' | 'offline' | 'unknown'
  latency: number | null
}

interface Subgroup {
  id: string
  name: string
  proxyCount: number
  status: 'healthy' | 'degraded' | 'down'
  image: string | null
  imageWidth: number
  imageHeight: number
  proxies: ProxyEntry[]
}

interface Preset {
  id: string
  name: string
  description: string
  isActive: boolean
  subgroups: Subgroup[]
  assignedUsers: number
}

// ─── Static Data ─────────────────────────────────────────────────────

const staticProxies: ProxyEntry[] = [
  { id: 'px_001', protocol: 'vless', address: 'sg1.corex.dev', port: 443, uuid: 'a1b2c3d4-e5f6-7890-abcd-ef1234567890', network: 'ws', tls: true, sni: 'sg1.corex.dev', wsPath: '/ws', wsHost: 'sg1.corex.dev', status: 'online', latency: 45 },
  { id: 'px_002', protocol: 'vless', address: 'sg2.corex.dev', port: 443, uuid: 'b2c3d4e5-f6a7-8901-bcde-f12345678901', network: 'tcp', tls: true, sni: 'sg2.corex.dev', flow: 'xtls-rprx-vision', clientFingerprint: 'chrome', realityPublicKey: 'abc123pub', realityShortId: 'abcd1234', status: 'online', latency: 52 },
  { id: 'px_003', protocol: 'vmess', address: 'jp1.corex.dev', port: 443, uuid: 'c3d4e5f6-a7b8-9012-cdef-123456789012', network: 'ws', tls: true, sni: 'jp1.corex.dev', cipher: 'auto', alterId: 0, wsPath: '/vmess', wsHost: 'jp1.corex.dev', status: 'online', latency: 78 },
  { id: 'px_004', protocol: 'vmess', address: 'jp2.corex.dev', port: 8080, uuid: 'd4e5f6a7-b8c9-0123-defa-234567890123', network: 'grpc', tls: true, sni: 'jp2.corex.dev', cipher: 'auto', alterId: 0, grpcService: 'grpc-service', status: 'offline', latency: null },
  { id: 'px_005', protocol: 'trojan', address: 'us1.corex.dev', port: 443, password: 'trojan-pass-001', network: 'tcp', tls: true, sni: 'us1.corex.dev', status: 'online', latency: 120 },
  { id: 'px_006', protocol: 'trojan', address: 'us2.corex.dev', port: 443, password: 'trojan-pass-002', network: 'ws', tls: true, sni: 'us2.corex.dev', wsPath: '/trojan-ws', wsHost: 'us2.corex.dev', status: 'online', latency: 135 },
  { id: 'px_007', protocol: 'ss', address: 'hk1.corex.dev', port: 8388, password: 'ss-pass-001', cipher: 'aes-256-gcm', udp: false, status: 'online', latency: 65 },
  { id: 'px_008', protocol: 'ss', address: 'hk2.corex.dev', port: 8388, password: 'ss-pass-002', cipher: 'chacha20-ietf-poly1305', udp: true, plugin: 'obfs', pluginOptsMode: 'http_simple', pluginOptsHost: 'hk2.corex.dev', status: 'unknown', latency: null },
  { id: 'px_009', protocol: 'ssr', address: 'in1.corex.dev', port: 9100, password: 'ssr-pass-001', cipher: 'aes-256-cfb', ssrProtocol: 'auth_aes128_sha1', obfs: 'tls1.2_ticket_auth', obfsParam: 'in1.corex.dev', status: 'online', latency: 95 },
  { id: 'px_010', protocol: 'wireguard', address: 'wg1.corex.dev', port: 51820, privateKey: 'wg-private-key', publicKey: 'wg-public-key', dns: '1.1.1.1', mtu: 1280, status: 'online', latency: 88 },
  { id: 'px_011', protocol: 'socks5', address: 'proxy1.corex.dev', port: 1080, username: 'socks_user', password: 'socks_pass', tls: false, status: 'online', latency: 72 },
  { id: 'px_012', protocol: 'http', address: 'proxy2.corex.dev', port: 8080, username: 'http_user', password: 'http_pass', tls: false, status: 'unknown', latency: null },
]

const staticPresets: Preset[] = [
  {
    id: 'preset_001',
    name: 'Bangladesh Premium',
    description: 'Optimized for Bangladesh users with low latency servers',
    isActive: true,
    assignedUsers: 156,
    subgroups: [
      {
        id: 'sg_001',
        name: 'Singapore Nodes',
        proxyCount: 3,
        status: 'healthy',
        image: null,
        imageWidth: 200,
        imageHeight: 100,
        proxies: staticProxies.filter((p) => ['px_001', 'px_002', 'px_003'].includes(p.id)),
      },
      {
        id: 'sg_002',
        name: 'Hong Kong Nodes',
        proxyCount: 2,
        status: 'healthy',
        image: null,
        imageWidth: 200,
        imageHeight: 100,
        proxies: staticProxies.filter((p) => ['px_007', 'px_008'].includes(p.id)),
      },
    ],
  },
  {
    id: 'preset_002',
    name: 'Asia Pacific',
    description: 'Wide coverage across Asia Pacific region',
    isActive: true,
    assignedUsers: 89,
    subgroups: [
      {
        id: 'sg_003',
        name: 'Japan Nodes',
        proxyCount: 2,
        status: 'degraded',
        image: null,
        imageWidth: 200,
        imageHeight: 100,
        proxies: staticProxies.filter((p) => ['px_003', 'px_004'].includes(p.id)),
      },
      {
        id: 'sg_004',
        name: 'India Nodes',
        proxyCount: 1,
        status: 'healthy',
        image: null,
        imageWidth: 200,
        imageHeight: 100,
        proxies: staticProxies.filter((p) => p.id === 'px_009'),
      },
    ],
  },
  {
    id: 'preset_003',
    name: 'Global Mix',
    description: 'Balanced worldwide distribution for all regions',
    isActive: false,
    assignedUsers: 42,
    subgroups: [
      {
        id: 'sg_005',
        name: 'US Nodes',
        proxyCount: 2,
        status: 'healthy',
        image: null,
        imageWidth: 200,
        imageHeight: 100,
        proxies: staticProxies.filter((p) => ['px_005', 'px_006'].includes(p.id)),
      },
      {
        id: 'sg_006',
        name: 'WireGuard & Others',
        proxyCount: 3,
        status: 'healthy',
        image: null,
        imageWidth: 200,
        imageHeight: 100,
        proxies: staticProxies.filter((p) => ['px_010', 'px_011', 'px_012'].includes(p.id)),
      },
    ],
  },
]

// ─── Constants ───────────────────────────────────────────────────────

const PROTOCOLS: { value: ProxyProtocol; label: string }[] = [
  { value: 'vless', label: 'VLESS' },
  { value: 'vmess', label: 'VMess' },
  { value: 'trojan', label: 'Trojan' },
  { value: 'ss', label: 'Shadowsocks' },
  { value: 'ssr', label: 'ShadowsocksR' },
  { value: 'wireguard', label: 'WireGuard' },
  { value: 'socks5', label: 'Socks5' },
  { value: 'http', label: 'HTTP' },
]

const PROTOCOL_COLORS: Record<ProxyProtocol, string> = {
  vless: 'bg-purple-500/15 text-purple-600 border-purple-500/30',
  vmess: 'bg-blue-500/15 text-blue-600 border-blue-500/30',
  trojan: 'bg-red-500/15 text-red-600 border-red-500/30',
  ss: 'bg-emerald-500/15 text-emerald-600 border-emerald-500/30',
  ssr: 'bg-amber-500/15 text-amber-600 border-amber-500/30',
  wireguard: 'bg-teal-500/15 text-teal-600 border-teal-500/30',
  socks5: 'bg-gray-500/15 text-gray-600 border-gray-500/30',
  http: 'bg-orange-500/15 text-orange-600 border-orange-500/30',
}

const NETWORK_OPTIONS = ['tcp', 'ws', 'grpc', 'h2']
const FLOW_OPTIONS = ['', 'xtls-rprx-vision', 'xtls-rprx-vision-udp443']
const VMESS_CIPHER_OPTIONS = ['auto', 'aes-128-gcm', 'chacha20-poly1305', 'none']
const SS_CIPHER_OPTIONS = [
  'aes-128-gcm', 'aes-192-gcm', 'aes-256-gcm',
  'chacha20-ietf-poly1305', 'xchacha20-ietf-poly1305',
  '2022-blake3-aes-128-gcm', '2022-blake3-aes-256-gcm',
]
const SSR_CIPHER_OPTIONS = ['aes-128-cfb', 'aes-192-cfb', 'aes-256-cfb', 'chacha20-ietf', 'rc4-md5']
const SSR_PROTOCOL_OPTIONS = ['origin', 'auth_sha1_v4', 'auth_aes128_md5', 'auth_aes128_sha1']
const SSR_OBFS_OPTIONS = ['plain', 'http_simple', 'tls1.2_ticket_auth']
const CLIENT_FINGERPRINT_OPTIONS = ['chrome', 'firefox', 'safari', 'ios', 'android', 'edge']
const SS_PLUGIN_OPTIONS = ['', 'obfs', 'v2ray-plugin']

// ─── Default proxy form per protocol ─────────────────────────────────

function getDefaultProxyForm(protocol: ProxyProtocol): Partial<ProxyEntry> {
  const base = {
    protocol,
    address: '',
    port: 443,
    status: 'unknown' as const,
    latency: null,
  }

  switch (protocol) {
    case 'vless':
      return { ...base, uuid: '', network: 'tcp', tls: false, flow: '', clientFingerprint: '' }
    case 'vmess':
      return { ...base, uuid: '', network: 'tcp', tls: false, cipher: 'auto', alterId: 0, skipCertVerify: false }
    case 'trojan':
      return { ...base, password: '', network: 'tcp', tls: true, skipCertVerify: false }
    case 'ss':
      return { ...base, password: '', cipher: 'aes-256-gcm', udp: false, plugin: '' }
    case 'ssr':
      return { ...base, password: '', cipher: 'aes-256-cfb', ssrProtocol: 'origin', obfs: 'plain', obfsParam: '' }
    case 'wireguard':
      return { ...base, port: 51820, privateKey: '', publicKey: '', presharedKey: '', dns: '', mtu: 1280 }
    case 'socks5':
      return { ...base, port: 1080, username: '', password: '', tls: false, skipCertVerify: false }
    case 'http':
      return { ...base, port: 8080, username: '', password: '', tls: false, skipCertVerify: false }
  }
}

// ─── Status Dot ──────────────────────────────────────────────────────

function StatusDot({ status }: { status: string }) {
  const colors: Record<string, string> = {
    healthy: 'bg-emerald-500',
    degraded: 'bg-amber-500',
    down: 'bg-red-500',
    online: 'bg-emerald-500',
    offline: 'bg-red-500',
    unknown: 'bg-gray-500',
    degraded_status: 'bg-amber-500',
    active: 'bg-emerald-500',
    inactive: 'bg-gray-500',
  }
  return (
    <span
      className={`inline-block size-2.5 rounded-full ${colors[status] ?? 'bg-gray-500'}`}
    />
  )
}

// ─── Protocol Badge ──────────────────────────────────────────────────

function ProtocolBadge({ protocol }: { protocol: ProxyProtocol }) {
  const label = PROTOCOLS.find((p) => p.value === protocol)?.label ?? protocol.toUpperCase()
  return (
    <Badge variant="outline" className={`text-xs font-semibold ${PROTOCOL_COLORS[protocol] ?? ''}`}>
      {label}
    </Badge>
  )
}

// ─── Main Component ──────────────────────────────────────────────────

export function AdminProxiesPreset() {
  const [presets, setPresets] = useState<Preset[]>(staticPresets)
  const [selectedPresetId, setSelectedPresetId] = useState<string | null>(null)
  const [expandedSubgroups, setExpandedSubgroups] = useState<Set<string>>(new Set())

  // Preset dialog
  const [presetDialogOpen, setPresetDialogOpen] = useState(false)
  const [editingPreset, setEditingPreset] = useState<Preset | null>(null)
  const [presetForm, setPresetForm] = useState({ name: '', description: '', isActive: true })

  // Subgroup dialog
  const [subgroupDialogOpen, setSubgroupDialogOpen] = useState(false)
  const [subgroupForm, setSubgroupForm] = useState({ name: '', imageWidth: 200, imageHeight: 100 })

  // Proxy dialog
  const [proxyDialogOpen, setProxyDialogOpen] = useState(false)
  const [editingProxy, setEditingProxy] = useState<ProxyEntry | null>(null)
  const [proxyTargetSgId, setProxyTargetSgId] = useState<string | null>(null)
  const [proxyForm, setProxyForm] = useState<Partial<ProxyEntry>>(getDefaultProxyForm('vless'))

  // Bulk upload dialog
  const [bulkUploadOpen, setBulkUploadOpen] = useState(false)
  const [bulkUploadTarget, setBulkUploadTarget] = useState<string | null>(null)
  const [bulkUploadData, setBulkUploadData] = useState('')
  const [bulkUploadTab, setBulkUploadTab] = useState('csv')

  // Delete dialogs
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [deletingPresetId, setDeletingPresetId] = useState<string | null>(null)

  // Health check
  const [healthCheckRunning, setHealthCheckRunning] = useState(false)
  const [healthSummary, setHealthSummary] = useState<{ healthy: number; degraded: number; down: number } | null>(null)

  const selectedPreset = presets.find((p) => p.id === selectedPresetId)

  // ─── Callbacks ──────────────────────────────────────────────────

  const toggleSubgroup = useCallback((sgId: string) => {
    setExpandedSubgroups((prev) => {
      const next = new Set(prev)
      if (next.has(sgId)) next.delete(sgId)
      else next.add(sgId)
      return next
    })
  }, [])

  // Add/Edit preset
  const openAddPreset = () => {
    setEditingPreset(null)
    setPresetForm({ name: '', description: '', isActive: true })
    setPresetDialogOpen(true)
  }

  const openEditPreset = (preset: Preset) => {
    setEditingPreset(preset)
    setPresetForm({ name: preset.name, description: preset.description, isActive: preset.isActive })
    setPresetDialogOpen(true)
  }

  const savePreset = () => {
    if (!presetForm.name.trim()) {
      toast.error('Preset name is required')
      return
    }
    if (editingPreset) {
      setPresets((prev) =>
        prev.map((p) =>
          p.id === editingPreset.id
            ? { ...p, name: presetForm.name, description: presetForm.description, isActive: presetForm.isActive }
            : p
        )
      )
      toast.success('Preset updated successfully')
    } else {
      const newPreset: Preset = {
        id: `preset_${Date.now()}`,
        name: presetForm.name,
        description: presetForm.description,
        isActive: presetForm.isActive,
        subgroups: [],
        assignedUsers: 0,
      }
      setPresets((prev) => [...prev, newPreset])
      toast.success('Preset created successfully')
    }
    setPresetDialogOpen(false)
  }

  // Delete preset
  const confirmDeletePreset = (id: string) => {
    setDeletingPresetId(id)
    setDeleteDialogOpen(true)
  }

  const deletePreset = () => {
    setPresets((prev) => prev.filter((p) => p.id !== deletingPresetId))
    if (selectedPresetId === deletingPresetId) setSelectedPresetId(null)
    setDeleteDialogOpen(false)
    toast.success('Preset deleted')
  }

  // Add subgroup
  const openAddSubgroup = () => {
    setSubgroupForm({ name: '', imageWidth: 200, imageHeight: 100 })
    setSubgroupDialogOpen(true)
  }

  const saveSubgroup = () => {
    if (!selectedPresetId || !subgroupForm.name.trim()) {
      toast.error('Subgroup name is required')
      return
    }
    const newSg: Subgroup = {
      id: `sg_${Date.now()}`,
      name: subgroupForm.name,
      proxyCount: 0,
      status: 'healthy',
      image: null,
      imageWidth: subgroupForm.imageWidth,
      imageHeight: subgroupForm.imageHeight,
      proxies: [],
    }
    setPresets((prev) =>
      prev.map((p) =>
        p.id === selectedPresetId ? { ...p, subgroups: [...p.subgroups, newSg] } : p
      )
    )
    setSubgroupDialogOpen(false)
    toast.success('Subgroup added')
  }

  // Delete subgroup
  const deleteSubgroup = (sgId: string) => {
    if (!selectedPresetId) return
    setPresets((prev) =>
      prev.map((p) =>
        p.id === selectedPresetId
          ? { ...p, subgroups: p.subgroups.filter((sg) => sg.id !== sgId) }
          : p
      )
    )
    toast.success('Subgroup deleted')
  }

  // ─── Proxy Add/Edit ────────────────────────────────────────────

  const openAddProxy = (sgId: string) => {
    setEditingProxy(null)
    setProxyTargetSgId(sgId)
    setProxyForm(getDefaultProxyForm('vless'))
    setProxyDialogOpen(true)
  }

  const openEditProxy = (sgId: string, proxy: ProxyEntry) => {
    setEditingProxy(proxy)
    setProxyTargetSgId(sgId)
    setProxyForm({ ...proxy })
    setProxyDialogOpen(true)
  }

  const handleProtocolChange = (protocol: ProxyProtocol) => {
    setProxyForm((prev) => {
      const defaults = getDefaultProxyForm(protocol)
      return {
        ...defaults,
        address: prev.address || defaults.address || '',
        port: prev.port || defaults.port || 443,
      }
    })
  }

  const saveProxy = () => {
    if (!selectedPresetId || !proxyTargetSgId) return
    if (!proxyForm.address?.trim()) {
      toast.error('Address is required')
      return
    }
    if (!proxyForm.port) {
      toast.error('Port is required')
      return
    }

    if (editingProxy) {
      const updated = { ...editingProxy, ...proxyForm } as ProxyEntry
      setPresets((prev) =>
        prev.map((p) =>
          p.id === selectedPresetId
            ? {
                ...p,
                subgroups: p.subgroups.map((sg) =>
                  sg.id === proxyTargetSgId
                    ? { ...sg, proxies: sg.proxies.map((px) => (px.id === editingProxy.id ? updated : px)) }
                    : sg
                ),
              }
            : p
        )
      )
      toast.success('Proxy updated')
    } else {
      const newProxy: ProxyEntry = {
        id: `px_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        protocol: proxyForm.protocol ?? 'vless',
        address: proxyForm.address ?? '',
        port: proxyForm.port ?? 443,
        uuid: proxyForm.uuid,
        password: proxyForm.password,
        username: proxyForm.username,
        flow: proxyForm.flow,
        network: proxyForm.network,
        tls: proxyForm.tls,
        sni: proxyForm.sni,
        alpn: proxyForm.alpn,
        cipher: proxyForm.cipher,
        alterId: proxyForm.alterId,
        skipCertVerify: proxyForm.skipCertVerify,
        realityPublicKey: proxyForm.realityPublicKey,
        realityShortId: proxyForm.realityShortId,
        clientFingerprint: proxyForm.clientFingerprint,
        grpcService: proxyForm.grpcService,
        wsPath: proxyForm.wsPath,
        wsHost: proxyForm.wsHost,
        udp: proxyForm.udp,
        plugin: proxyForm.plugin,
        pluginOptsMode: proxyForm.pluginOptsMode,
        pluginOptsHost: proxyForm.pluginOptsHost,
        ssrProtocol: proxyForm.ssrProtocol,
        obfs: proxyForm.obfs,
        obfsParam: proxyForm.obfsParam,
        privateKey: proxyForm.privateKey,
        publicKey: proxyForm.publicKey,
        presharedKey: proxyForm.presharedKey,
        dns: proxyForm.dns,
        mtu: proxyForm.mtu,
        status: proxyForm.status ?? 'unknown',
        latency: proxyForm.latency ?? null,
      }
      setPresets((prev) =>
        prev.map((p) =>
          p.id === selectedPresetId
            ? {
                ...p,
                subgroups: p.subgroups.map((sg) =>
                  sg.id === proxyTargetSgId
                    ? { ...sg, proxies: [...sg.proxies, newProxy], proxyCount: sg.proxies.length + 1 }
                    : sg
                ),
              }
            : p
        )
      )
      toast.success('Proxy added')
    }
    setProxyDialogOpen(false)
  }

  // Delete proxy
  const deleteProxy = (sgId: string, proxyId: string) => {
    if (!selectedPresetId) return
    setPresets((prev) =>
      prev.map((p) =>
        p.id === selectedPresetId
          ? {
              ...p,
              subgroups: p.subgroups.map((sg) =>
                sg.id === sgId
                  ? { ...sg, proxies: sg.proxies.filter((px) => px.id !== proxyId), proxyCount: sg.proxies.length - 1 }
                  : sg
              ),
            }
          : p
      )
    )
    toast.success('Proxy removed')
  }

  // ─── Bulk Upload ───────────────────────────────────────────────

  const openBulkUpload = (sgId: string) => {
    setBulkUploadTarget(sgId)
    setBulkUploadData('')
    setBulkUploadTab('csv')
    setBulkUploadOpen(true)
  }

  const processBulkUpload = () => {
    if (!selectedPresetId || !bulkUploadTarget || !bulkUploadData.trim()) {
      toast.error('No data to upload')
      return
    }

    let newProxies: ProxyEntry[] = []

    try {
      if (bulkUploadTab === 'csv') {
        const lines = bulkUploadData.trim().split('\n')
        const dataLines = lines[0]?.toLowerCase().includes('protocol') ? lines.slice(1) : lines
        newProxies = dataLines
          .filter((l) => l.trim())
          .map((line, i) => {
            const parts = line.split(',').map((s) => s.trim())
            const protocol = (parts[0] || 'ss') as ProxyProtocol
            return {
              id: `px_upload_${Date.now()}_${i}`,
              protocol,
              address: parts[1] || '0.0.0.0',
              port: parseInt(parts[2]) || 443,
              uuid: ['vless', 'vmess'].includes(protocol) ? (parts[3] || '') : undefined,
              password: ['trojan', 'ss', 'ssr'].includes(protocol) ? (parts[3] || '') : undefined,
              username: ['socks5', 'http'].includes(protocol) ? (parts[3] || '') : undefined,
              status: 'unknown' as const,
              latency: null,
            }
          })
      } else {
        const parsed = JSON.parse(bulkUploadData)
        const arr = Array.isArray(parsed) ? parsed : [parsed]
        newProxies = arr.map((item: Record<string, unknown>, i: number) => ({
          id: `px_upload_${Date.now()}_${i}`,
          protocol: (item.protocol as ProxyProtocol) || 'ss',
          address: (item.address as string) || '0.0.0.0',
          port: (item.port as number) || 443,
          uuid: (item.uuid as string) || undefined,
          password: (item.password as string) || undefined,
          username: (item.username as string) || undefined,
          network: (item.network as string) || undefined,
          tls: (item.tls as boolean) || undefined,
          sni: (item.sni as string) || undefined,
          cipher: (item.cipher as string) || undefined,
          flow: (item.flow as string) || undefined,
          wsPath: (item.wsPath as string) || (item['ws-opts'] as Record<string, string>)?.path || undefined,
          wsHost: (item.wsHost as string) || (item['ws-opts'] as Record<string, string>)?.host || undefined,
          grpcService: (item.grpcService as string) || (item['grpc-opts'] as Record<string, string>)?.serviceName || undefined,
          status: 'unknown' as const,
          latency: null,
        }))
      }
    } catch {
      toast.error('Failed to parse proxy data. Check format.')
      return
    }

    if (newProxies.length === 0) {
      toast.error('No valid proxies found')
      return
    }

    setPresets((prev) =>
      prev.map((p) =>
        p.id === selectedPresetId
          ? {
              ...p,
              subgroups: p.subgroups.map((sg) =>
                sg.id === bulkUploadTarget
                  ? { ...sg, proxies: [...sg.proxies, ...newProxies], proxyCount: sg.proxies.length + newProxies.length }
                  : sg
              ),
            }
          : p
      )
    )
    setBulkUploadOpen(false)
    toast.success(`${newProxies.length} proxies added`)
  }

  // ─── Health Check ──────────────────────────────────────────────

  const healthCheckProxy = (sgId: string, proxyId: string) => {
    if (!selectedPresetId) return
    const statuses: ProxyEntry['status'][] = ['online', 'online', 'online', 'offline']
    setPresets((prev) =>
      prev.map((p) =>
        p.id === selectedPresetId
          ? {
              ...p,
              subgroups: p.subgroups.map((sg) =>
                sg.id === sgId
                  ? {
                      ...sg,
                      proxies: sg.proxies.map((px) =>
                        px.id === proxyId
                          ? { ...px, status: statuses[Math.floor(Math.random() * statuses.length)], latency: Math.floor(Math.random() * 150) + 5 }
                          : px
                      ),
                    }
                  : sg
              ),
            }
          : p
      )
    )
    toast.success('Proxy health checked')
  }

  const healthCheckSubgroup = (sgId: string) => {
    if (!selectedPresetId) return
    const proxyStatuses: ProxyEntry['status'][] = ['online', 'online', 'online', 'offline', 'unknown']
    const subStatuses: Subgroup['status'][] = ['healthy', 'healthy', 'degraded', 'down']

    setPresets((prev) =>
      prev.map((p) =>
        p.id === selectedPresetId
          ? {
              ...p,
              subgroups: p.subgroups.map((sg) =>
                sg.id === sgId
                  ? {
                      ...sg,
                      status: subStatuses[Math.floor(Math.random() * subStatuses.length)],
                      proxies: sg.proxies.map((px) => ({
                        ...px,
                        status: proxyStatuses[Math.floor(Math.random() * proxyStatuses.length)],
                        latency: Math.floor(Math.random() * 200) + 10,
                      })),
                    }
                  : sg
              ),
            }
          : p
      )
    )
    toast.success('Subgroup health checked')
  }

  const healthCheckAll = () => {
    setHealthCheckRunning(true)
    setTimeout(() => {
      const proxyStatuses: ProxyEntry['status'][] = ['online', 'online', 'online', 'offline', 'unknown']
      const subStatuses: Subgroup['status'][] = ['healthy', 'healthy', 'degraded', 'down']
      let h = 0
      let d = 0
      let dn = 0

      setPresets((prev) =>
        prev.map((p) => ({
          ...p,
          subgroups: p.subgroups.map((sg) => {
            const newStatus = subStatuses[Math.floor(Math.random() * subStatuses.length)]
            if (newStatus === 'healthy') h++
            else if (newStatus === 'degraded') d++
            else dn++
            return {
              ...sg,
              status: newStatus,
              proxies: sg.proxies.map((px) => ({
                ...px,
                status: proxyStatuses[Math.floor(Math.random() * proxyStatuses.length)],
                latency: Math.floor(Math.random() * 200) + 10,
              })),
            }
          }),
        }))
      )
      setHealthSummary({ healthy: h, degraded: d, down: dn })
      setHealthCheckRunning(false)
      toast.success('Health check complete')
    }, 1500)
  }

  // Image upload mock
  const uploadSubgroupImage = (sgId: string) => {
    if (!selectedPresetId) return
    setPresets((prev) =>
      prev.map((p) =>
        p.id === selectedPresetId
          ? {
              ...p,
              subgroups: p.subgroups.map((sg) =>
                sg.id === sgId
                  ? {
                      ...sg,
                      image: `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='${sg.imageWidth}' height='${sg.imageHeight}'%3E%3Crect width='100%25' height='100%25' fill='%2310b981'/%3E%3Ctext x='50%25' y='50%25' text-anchor='middle' dy='.3em' fill='white' font-size='14'%3E${encodeURIComponent(sg.name)}%3C/text%3E%3C/svg%3E`,
                    }
                  : sg
              ),
            }
          : p
      )
    )
    toast.success('Image uploaded (mock)')
  }

  const updateSubgroupImageSize = (sgId: string, width: number, height: number) => {
    if (!selectedPresetId) return
    setPresets((prev) =>
      prev.map((p) =>
        p.id === selectedPresetId
          ? { ...p, subgroups: p.subgroups.map((sg) => (sg.id === sgId ? { ...sg, imageWidth: width, imageHeight: height } : sg)) }
          : p
      )
    )
  }

  // ─── Bulk Upload Examples ──────────────────────────────────────

  const csvExamples = useMemo(() => ({
    vless: `protocol,address,port,uuid,network,tls,sni,wsPath,wsHost,flow,realityPublicKey,realityShortId,clientFingerprint,grpcService
vless,node1.example.com,443,your-uuid-here,ws,true,example.com,/ws,example.com,,,,
vless,node2.example.com,443,your-uuid-here,tcp,true,example.com,,,,abc123pub,abcd1234,chrome,`,
    vmess: `protocol,address,port,uuid,network,tls,cipher,alterId,sni,wsPath,wsHost,grpcService,skipCertVerify
vmess,node1.example.com,443,your-uuid-here,ws,true,auto,0,example.com,/ws,example.com,,false
vmess,node2.example.com,8080,your-uuid-here,grpc,true,auto,0,example.com,,,,grpc-service,false`,
    trojan: `protocol,address,port,password,network,tls,sni,wsPath,wsHost,grpcService,skipCertVerify
trojan,node1.example.com,443,your-password,tcp,true,example.com,,,,false
trojan,node2.example.com,443,your-password,ws,true,example.com,/ws,example.com,,false`,
    ss: `protocol,address,port,password,cipher,udp,plugin,pluginOptsMode,pluginOptsHost
ss,node1.example.com,8388,your-password,aes-256-gcm,false,,,
ss,node2.example.com,8388,your-password,chacha20-ietf-poly1305,true,obfs,http_simple,example.com`,
    ssr: `protocol,address,port,password,cipher,protocol,obfs,obfsParam
ssr,node1.example.com,9100,your-password,aes-256-cfb,auth_aes128_sha1,tls1.2_ticket_auth,example.com`,
    wireguard: `protocol,address,port,privateKey,publicKey,presharedKey,dns,mtu
wireguard,wg1.example.com,51820,your-private-key,your-public-key,,1.1.1.1,1280`,
    socks5: `protocol,address,port,username,password,tls,skipCertVerify
socks5,proxy.example.com,1080,user,pass,false,false`,
    http: `protocol,address,port,username,password,tls,skipCertVerify
http,proxy.example.com,8080,user,pass,false,false`,
  }), [])

  const jsonExamples = useMemo(() => ({
    vless: `[
  {
    "protocol": "vless",
    "address": "node1.example.com",
    "port": 443,
    "uuid": "your-uuid-here",
    "network": "ws",
    "tls": true,
    "sni": "example.com",
    "wsPath": "/ws",
    "wsHost": "example.com"
  }
]`,
    vmess: `[
  {
    "protocol": "vmess",
    "address": "node1.example.com",
    "port": 443,
    "uuid": "your-uuid-here",
    "network": "grpc",
    "tls": true,
    "cipher": "auto",
    "grpcService": "grpc-service"
  }
]`,
    trojan: `[
  {
    "protocol": "trojan",
    "address": "node1.example.com",
    "port": 443,
    "password": "your-password",
    "network": "tcp",
    "tls": true,
    "sni": "example.com"
  }
]`,
    ss: `[
  {
    "protocol": "ss",
    "address": "node1.example.com",
    "port": 8388,
    "password": "your-password",
    "cipher": "aes-256-gcm"
  }
]`,
    ssr: `[
  {
    "protocol": "ssr",
    "address": "node1.example.com",
    "port": 9100,
    "password": "your-password",
    "cipher": "aes-256-cfb",
    "ssrProtocol": "auth_aes128_sha1",
    "obfs": "tls1.2_ticket_auth"
  }
]`,
    wireguard: `[
  {
    "protocol": "wireguard",
    "address": "wg1.example.com",
    "port": 51820,
    "privateKey": "your-private-key",
    "publicKey": "your-public-key",
    "dns": "1.1.1.1",
    "mtu": 1280
  }
]`,
    socks5: `[
  {
    "protocol": "socks5",
    "address": "proxy.example.com",
    "port": 1080,
    "username": "user",
    "password": "pass"
  }
]`,
    http: `[
  {
    "protocol": "http",
    "address": "proxy.example.com",
    "port": 8080,
    "username": "user",
    "password": "pass"
  }
]`,
  }), [])

  // ─── Proxy Form Fields ─────────────────────────────────────────

  const renderProxyFormFields = () => {
    const protocol = proxyForm.protocol ?? 'vless'

    // Auth field based on protocol
    const renderAuthField = () => {
      if (['vless', 'vmess'].includes(protocol)) {
        return (
          <div className="space-y-2">
            <Label>UUID</Label>
            <Input
              value={proxyForm.uuid ?? ''}
              onChange={(e) => setProxyForm((f) => ({ ...f, uuid: e.target.value }))}
              placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
            />
          </div>
        )
      }
      if (['trojan', 'ss', 'ssr'].includes(protocol)) {
        return (
          <div className="space-y-2">
            <Label>Password</Label>
            <Input
              value={proxyForm.password ?? ''}
              onChange={(e) => setProxyForm((f) => ({ ...f, password: e.target.value }))}
              placeholder="Password"
              type="password"
            />
          </div>
        )
      }
      if (['wireguard'].includes(protocol)) {
        return (
          <div className="space-y-2">
            <Label>Private Key</Label>
            <Input
              value={proxyForm.privateKey ?? ''}
              onChange={(e) => setProxyForm((f) => ({ ...f, privateKey: e.target.value }))}
              placeholder="Private key"
              type="password"
            />
          </div>
        )
      }
      if (['socks5', 'http'].includes(protocol)) {
        return (
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>Username (optional)</Label>
              <Input
                value={proxyForm.username ?? ''}
                onChange={(e) => setProxyForm((f) => ({ ...f, username: e.target.value }))}
                placeholder="Username"
              />
            </div>
            <div className="space-y-2">
              <Label>Password (optional)</Label>
              <Input
                value={proxyForm.password ?? ''}
                onChange={(e) => setProxyForm((f) => ({ ...f, password: e.target.value }))}
                placeholder="Password"
                type="password"
              />
            </div>
          </div>
        )
      }
      return null
    }

    // Network selector (for protocols that support it)
    const renderNetworkField = () => {
      if (!['vless', 'vmess', 'trojan'].includes(protocol)) return null
      return (
        <div className="space-y-2">
          <Label>Network</Label>
          <Select
            value={proxyForm.network ?? 'tcp'}
            onValueChange={(v) => setProxyForm((f) => ({ ...f, network: v }))}
          >
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {NETWORK_OPTIONS.map((n) => (
                <SelectItem key={n} value={n}>{n.toUpperCase()}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )
    }

    // TLS toggle
    const renderTlsField = () => {
      if (!['vless', 'vmess', 'trojan', 'socks5', 'http'].includes(protocol)) return null
      return (
        <div className="flex items-center justify-between">
          <Label>TLS</Label>
          <Switch
            checked={proxyForm.tls ?? false}
            onCheckedChange={(checked) => setProxyForm((f) => ({ ...f, tls: checked }))}
          />
        </div>
      )
    }

    // SNI
    const renderSniField = () => {
      if (!['vless', 'vmess', 'trojan'].includes(protocol)) return null
      return (
        <div className="space-y-2">
          <Label>SNI / Server Name</Label>
          <Input
            value={proxyForm.sni ?? ''}
            onChange={(e) => setProxyForm((f) => ({ ...f, sni: e.target.value }))}
            placeholder="example.com"
          />
        </div>
      )
    }

    // Skip cert verify
    const renderSkipCertVerify = () => {
      if (!['vmess', 'trojan', 'socks5', 'http'].includes(protocol)) return null
      return (
        <div className="flex items-center justify-between">
          <Label>Skip Cert Verify</Label>
          <Switch
            checked={proxyForm.skipCertVerify ?? false}
            onCheckedChange={(checked) => setProxyForm((f) => ({ ...f, skipCertVerify: checked }))}
          />
        </div>
      )
    }

    // VLESS: Flow
    const renderVlessFields = () => {
      if (protocol !== 'vless') return null
      return (
        <>
          <div className="space-y-2">
            <Label>Flow</Label>
            <Select
              value={proxyForm.flow ?? ''}
              onValueChange={(v) => setProxyForm((f) => ({ ...f, flow: v }))}
            >
              <SelectTrigger><SelectValue placeholder="Select flow" /></SelectTrigger>
              <SelectContent>
                {FLOW_OPTIONS.map((f) => (
                  <SelectItem key={f} value={f || 'none'}>{f || 'None'}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Client Fingerprint</Label>
            <Select
              value={proxyForm.clientFingerprint ?? ''}
              onValueChange={(v) => setProxyForm((f) => ({ ...f, clientFingerprint: v }))}
            >
              <SelectTrigger><SelectValue placeholder="Select fingerprint" /></SelectTrigger>
              <SelectContent>
                {CLIENT_FINGERPRINT_OPTIONS.map((fp) => (
                  <SelectItem key={fp} value={fp}>{fp.charAt(0).toUpperCase() + fp.slice(1)}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </>
      )
    }

    // VLESS Reality fields
    const renderRealityFields = () => {
      if (protocol !== 'vless') return null
      return (
        <div className="space-y-3 rounded-lg border border-purple-500/20 bg-purple-500/5 p-3">
          <div className="text-sm font-medium text-purple-600">Reality Options</div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>Public Key</Label>
              <Input
                value={proxyForm.realityPublicKey ?? ''}
                onChange={(e) => setProxyForm((f) => ({ ...f, realityPublicKey: e.target.value }))}
                placeholder="Reality public key"
              />
            </div>
            <div className="space-y-2">
              <Label>Short ID</Label>
              <Input
                value={proxyForm.realityShortId ?? ''}
                onChange={(e) => setProxyForm((f) => ({ ...f, realityShortId: e.target.value }))}
                placeholder="Short ID"
              />
            </div>
          </div>
        </div>
      )
    }

    // VMess specific
    const renderVmessFields = () => {
      if (protocol !== 'vmess') return null
      return (
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-2">
            <Label>Cipher</Label>
            <Select
              value={proxyForm.cipher ?? 'auto'}
              onValueChange={(v) => setProxyForm((f) => ({ ...f, cipher: v }))}
            >
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {VMESS_CIPHER_OPTIONS.map((c) => (
                  <SelectItem key={c} value={c}>{c}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Alter ID</Label>
            <Input
              type="number"
              value={proxyForm.alterId ?? 0}
              onChange={(e) => setProxyForm((f) => ({ ...f, alterId: parseInt(e.target.value) || 0 }))}
              min={0}
            />
          </div>
        </div>
      )
    }

    // gRPC opts (conditional on network=grpc)
    const renderGrpcFields = () => {
      if (proxyForm.network !== 'grpc') return null
      if (!['vless', 'vmess', 'trojan'].includes(protocol)) return null
      return (
        <div className="space-y-2">
          <Label>gRPC Service Name</Label>
          <Input
            value={proxyForm.grpcService ?? ''}
            onChange={(e) => setProxyForm((f) => ({ ...f, grpcService: e.target.value }))}
            placeholder="grpc-service-name"
          />
        </div>
      )
    }

    // WebSocket opts (conditional on network=ws)
    const renderWsFields = () => {
      if (proxyForm.network !== 'ws') return null
      if (!['vless', 'vmess', 'trojan'].includes(protocol)) return null
      return (
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-2">
            <Label>WS Path</Label>
            <Input
              value={proxyForm.wsPath ?? ''}
              onChange={(e) => setProxyForm((f) => ({ ...f, wsPath: e.target.value }))}
              placeholder="/ws"
            />
          </div>
          <div className="space-y-2">
            <Label>WS Host</Label>
            <Input
              value={proxyForm.wsHost ?? ''}
              onChange={(e) => setProxyForm((f) => ({ ...f, wsHost: e.target.value }))}
              placeholder="example.com"
            />
          </div>
        </div>
      )
    }

    // SS specific
    const renderSsFields = () => {
      if (protocol !== 'ss') return null
      return (
        <>
          <div className="space-y-2">
            <Label>Cipher</Label>
            <Select
              value={proxyForm.cipher ?? 'aes-256-gcm'}
              onValueChange={(v) => setProxyForm((f) => ({ ...f, cipher: v }))}
            >
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {SS_CIPHER_OPTIONS.map((c) => (
                  <SelectItem key={c} value={c}>{c}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-center justify-between">
            <Label>UDP</Label>
            <Switch
              checked={proxyForm.udp ?? false}
              onCheckedChange={(checked) => setProxyForm((f) => ({ ...f, udp: checked }))}
            />
          </div>
          <div className="space-y-2">
            <Label>Plugin</Label>
            <Select
              value={proxyForm.plugin ?? ''}
              onValueChange={(v) => setProxyForm((f) => ({ ...f, plugin: v }))}
            >
              <SelectTrigger><SelectValue placeholder="Select plugin" /></SelectTrigger>
              <SelectContent>
                {SS_PLUGIN_OPTIONS.map((p) => (
                  <SelectItem key={p} value={p || 'none'}>{p || 'None'}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          {proxyForm.plugin === 'obfs' && (
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label>Plugin Mode</Label>
                <Input
                  value={proxyForm.pluginOptsMode ?? ''}
                  onChange={(e) => setProxyForm((f) => ({ ...f, pluginOptsMode: e.target.value }))}
                  placeholder="http_simple"
                />
              </div>
              <div className="space-y-2">
                <Label>Plugin Host</Label>
                <Input
                  value={proxyForm.pluginOptsHost ?? ''}
                  onChange={(e) => setProxyForm((f) => ({ ...f, pluginOptsHost: e.target.value }))}
                  placeholder="example.com"
                />
              </div>
            </div>
          )}
        </>
      )
    }

    // SSR specific
    const renderSsrFields = () => {
      if (protocol !== 'ssr') return null
      return (
        <>
          <div className="space-y-2">
            <Label>Cipher</Label>
            <Select
              value={proxyForm.cipher ?? 'aes-256-cfb'}
              onValueChange={(v) => setProxyForm((f) => ({ ...f, cipher: v }))}
            >
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {SSR_CIPHER_OPTIONS.map((c) => (
                  <SelectItem key={c} value={c}>{c}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Protocol</Label>
            <Select
              value={proxyForm.ssrProtocol ?? 'origin'}
              onValueChange={(v) => setProxyForm((f) => ({ ...f, ssrProtocol: v }))}
            >
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {SSR_PROTOCOL_OPTIONS.map((p) => (
                  <SelectItem key={p} value={p}>{p}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Obfs</Label>
            <Select
              value={proxyForm.obfs ?? 'plain'}
              onValueChange={(v) => setProxyForm((f) => ({ ...f, obfs: v }))}
            >
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {SSR_OBFS_OPTIONS.map((o) => (
                  <SelectItem key={o} value={o}>{o}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Obfs Param</Label>
            <Input
              value={proxyForm.obfsParam ?? ''}
              onChange={(e) => setProxyForm((f) => ({ ...f, obfsParam: e.target.value }))}
              placeholder="example.com"
            />
          </div>
        </>
      )
    }

    // WireGuard specific
    const renderWireguardFields = () => {
      if (protocol !== 'wireguard') return null
      return (
        <>
          <div className="space-y-2">
            <Label>Public Key</Label>
            <Input
              value={proxyForm.publicKey ?? ''}
              onChange={(e) => setProxyForm((f) => ({ ...f, publicKey: e.target.value }))}
              placeholder="Public key"
            />
          </div>
          <div className="space-y-2">
            <Label>Preshared Key</Label>
            <Input
              value={proxyForm.presharedKey ?? ''}
              onChange={(e) => setProxyForm((f) => ({ ...f, presharedKey: e.target.value }))}
              placeholder="Preshared key (optional)"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>DNS</Label>
              <Input
                value={proxyForm.dns ?? ''}
                onChange={(e) => setProxyForm((f) => ({ ...f, dns: e.target.value }))}
                placeholder="1.1.1.1"
              />
            </div>
            <div className="space-y-2">
              <Label>MTU</Label>
              <Input
                type="number"
                value={proxyForm.mtu ?? 1280}
                onChange={(e) => setProxyForm((f) => ({ ...f, mtu: parseInt(e.target.value) || 1280 }))}
              />
            </div>
          </div>
        </>
      )
    }

    return (
      <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-1">
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-2">
            <Label>Protocol</Label>
            <Select value={protocol} onValueChange={(v) => handleProtocolChange(v as ProxyProtocol)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {PROTOCOLS.map((p) => (
                  <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Port</Label>
            <Input
              type="number"
              value={proxyForm.port ?? 443}
              onChange={(e) => setProxyForm((f) => ({ ...f, port: parseInt(e.target.value) || 443 }))}
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label>Address</Label>
          <Input
            value={proxyForm.address ?? ''}
            onChange={(e) => setProxyForm((f) => ({ ...f, address: e.target.value }))}
            placeholder="server.example.com"
          />
        </div>

        {renderAuthField()}
        {renderNetworkField()}
        {renderTlsField()}
        {renderSniField()}
        {renderSkipCertVerify()}
        {renderVlessFields()}
        {renderRealityFields()}
        {renderVmessFields()}
        {renderGrpcFields()}
        {renderWsFields()}
        {renderSsFields()}
        {renderSsrFields()}
        {renderWireguardFields()}
      </div>
    )
  }

  // ─── Render: Preset List ───────────────────────────────────────

  if (!selectedPreset) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Proxy Presets</h1>
            <p className="text-muted-foreground text-sm mt-1">
              Manage proxy presets, subgroups, and server configurations
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={healthCheckAll}
              disabled={healthCheckRunning}
              className="gap-1.5"
            >
              <HeartPulse className={`size-4 ${healthCheckRunning ? 'animate-pulse' : ''}`} />
              {healthCheckRunning ? 'Checking...' : 'Health Check All'}
            </Button>
            <Button size="sm" onClick={openAddPreset} className="gap-1.5">
              <Plus className="size-4" />
              Add Preset
            </Button>
          </div>
        </div>

        {healthSummary && (
          <div className="grid gap-3 sm:grid-cols-3">
            <Card className="border-emerald-500/30 bg-emerald-500/5">
              <CardContent className="p-3 flex items-center gap-2">
                <ShieldCheck className="size-4 text-emerald-500" />
                <span className="text-sm font-medium">{healthSummary.healthy} Healthy</span>
              </CardContent>
            </Card>
            <Card className="border-amber-500/30 bg-amber-500/5">
              <CardContent className="p-3 flex items-center gap-2">
                <Activity className="size-4 text-amber-500" />
                <span className="text-sm font-medium">{healthSummary.degraded} Degraded</span>
              </CardContent>
            </Card>
            <Card className="border-red-500/30 bg-red-500/5">
              <CardContent className="p-3 flex items-center gap-2">
                <Server className="size-4 text-red-500" />
                <span className="text-sm font-medium">{healthSummary.down} Down</span>
              </CardContent>
            </Card>
          </div>
        )}

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {presets.map((preset) => (
            <Card
              key={preset.id}
              className="cursor-pointer hover:border-primary/50 transition-colors"
              onClick={() => setSelectedPresetId(preset.id)}
            >
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base">{preset.name}</CardTitle>
                  <Badge variant={preset.isActive ? 'default' : 'secondary'}>
                    {preset.isActive ? 'Active' : 'Inactive'}
                  </Badge>
                </div>
                <CardDescription className="text-xs">{preset.description}</CardDescription>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Server className="size-3.5" />
                    {preset.subgroups.length} subgroups
                  </span>
                  <span className="flex items-center gap-1">
                    <Users className="size-3.5" />
                    {preset.assignedUsers} users
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Preset Add/Edit Dialog */}
        <Dialog open={presetDialogOpen} onOpenChange={setPresetDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>{editingPreset ? 'Edit Preset' : 'Add New Preset'}</DialogTitle>
              <DialogDescription>
                {editingPreset ? 'Update preset details' : 'Create a new proxy preset'}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Name</Label>
                <Input
                  value={presetForm.name}
                  onChange={(e) => setPresetForm((f) => ({ ...f, name: e.target.value }))}
                  placeholder="Preset name"
                />
              </div>
              <div className="space-y-2">
                <Label>Description</Label>
                <Textarea
                  value={presetForm.description}
                  onChange={(e) => setPresetForm((f) => ({ ...f, description: e.target.value }))}
                  placeholder="Preset description"
                  rows={3}
                />
              </div>
              <div className="flex items-center justify-between">
                <Label>Active</Label>
                <Switch
                  checked={presetForm.isActive}
                  onCheckedChange={(checked) => setPresetForm((f) => ({ ...f, isActive: checked }))}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setPresetDialogOpen(false)}>Cancel</Button>
              <Button onClick={savePreset}>Save</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Delete Confirmation */}
        <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete Preset</AlertDialogTitle>
              <AlertDialogDescription>
                Are you sure? This will permanently delete this preset and all its subgroups and proxies.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={deletePreset}>Delete</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    )
  }

  // ─── Render: Preset Detail ─────────────────────────────────────

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => setSelectedPresetId(null)}>
            <ArrowLeft className="size-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold tracking-tight">{selectedPreset.name}</h1>
            <p className="text-muted-foreground text-sm">{selectedPreset.description}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => openEditPreset(selectedPreset)} className="gap-1.5">
            <Pencil className="size-3.5" />
            Edit
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => confirmDeletePreset(selectedPreset.id)}
            className="gap-1.5 text-red-400 hover:text-red-300 hover:bg-red-500/10"
          >
            <Trash2 className="size-3.5" />
            Delete
          </Button>
        </div>
      </div>

      {/* Subgroups */}
      {selectedPreset.subgroups.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <Server className="size-12 mx-auto mb-3 text-muted-foreground/30" />
            <p className="font-medium text-muted-foreground">No subgroups yet</p>
            <p className="text-sm text-muted-foreground mb-4">Add a subgroup to start configuring proxies</p>
            <Button size="sm" onClick={openAddSubgroup} className="gap-1.5">
              <Plus className="size-3.5" />
              Add Subgroup
            </Button>
          </CardContent>
        </Card>
      ) : (
        selectedPreset.subgroups.map((sg) => (
          <Card key={sg.id} className="border-border/50">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div
                  className="flex items-center gap-3 cursor-pointer"
                  onClick={() => toggleSubgroup(sg.id)}
                >
                  {expandedSubgroups.has(sg.id) ? (
                    <ChevronDown className="size-5 text-muted-foreground" />
                  ) : (
                    <ChevronRight className="size-5 text-muted-foreground" />
                  )}
                  <div>
                    <CardTitle className="text-base flex items-center gap-2">
                      <StatusDot status={sg.status} />
                      {sg.name}
                    </CardTitle>
                    <CardDescription className="text-xs">
                      {sg.proxyCount} proxies • {sg.status}
                    </CardDescription>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="size-8"
                    onClick={() => healthCheckSubgroup(sg.id)}
                  >
                    <HeartPulse className="size-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="size-8"
                    onClick={() => uploadSubgroupImage(sg.id)}
                  >
                    <ImagePlus className="size-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="size-8"
                    onClick={() => openBulkUpload(sg.id)}
                  >
                    <Upload className="size-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => openAddProxy(sg.id)}
                    className="gap-1"
                  >
                    <Plus className="size-3.5" />
                    Add Proxy
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="size-8 text-red-400 hover:text-red-300"
                    onClick={() => deleteSubgroup(sg.id)}
                  >
                    <Trash2 className="size-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>

            {expandedSubgroups.has(sg.id) && (
              <CardContent>
                {sg.image && (
                  <div className="mb-4">
                    <img
                      src={sg.image}
                      alt={sg.name}
                      width={sg.imageWidth}
                      height={sg.imageHeight}
                      className="rounded-lg border max-w-full"
                    />
                    <div className="flex gap-2 mt-2">
                      <Input
                        type="number"
                        value={sg.imageWidth}
                        onChange={(e) => updateSubgroupImageSize(sg.id, parseInt(e.target.value) || 200, sg.imageHeight)}
                        className="w-24"
                        placeholder="Width"
                      />
                      <span className="self-center text-xs text-muted-foreground">×</span>
                      <Input
                        type="number"
                        value={sg.imageHeight}
                        onChange={(e) => updateSubgroupImageSize(sg.id, sg.imageWidth, parseInt(e.target.value) || 100)}
                        className="w-24"
                        placeholder="Height"
                      />
                    </div>
                  </div>
                )}

                {sg.proxies.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-4">No proxies in this subgroup</p>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Protocol</TableHead>
                          <TableHead>Address</TableHead>
                          <TableHead>Port</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Latency</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {sg.proxies.map((proxy) => (
                          <TableRow key={proxy.id}>
                            <TableCell><ProtocolBadge protocol={proxy.protocol} /></TableCell>
                            <TableCell className="font-mono text-xs">{proxy.address}</TableCell>
                            <TableCell>{proxy.port}</TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <StatusDot status={proxy.status} />
                                <span className="text-xs capitalize">{proxy.status}</span>
                              </div>
                            </TableCell>
                            <TableCell className="text-xs">
                              {proxy.latency !== null ? `${proxy.latency}ms` : '—'}
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-1">
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="size-7"
                                  onClick={() => healthCheckProxy(sg.id, proxy.id)}
                                >
                                  <HeartPulse className="size-3.5" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="size-7"
                                  onClick={() => openEditProxy(sg.id, proxy)}
                                >
                                  <Pencil className="size-3.5" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="size-7 text-red-400 hover:text-red-300"
                                  onClick={() => deleteProxy(sg.id, proxy.id)}
                                >
                                  <Trash2 className="size-3.5" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            )}
          </Card>
        ))
      )}

      {/* Add Subgroup Button */}
      {selectedPreset.subgroups.length > 0 && (
        <Button variant="outline" onClick={openAddSubgroup} className="gap-1.5">
          <Plus className="size-4" />
          Add Subgroup
        </Button>
      )}

      {/* Subgroup Dialog */}
      <Dialog open={subgroupDialogOpen} onOpenChange={setSubgroupDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add Subgroup</DialogTitle>
            <DialogDescription>Create a new subgroup within this preset</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Name</Label>
              <Input
                value={subgroupForm.name}
                onChange={(e) => setSubgroupForm((f) => ({ ...f, name: e.target.value }))}
                placeholder="Subgroup name"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label>Image Width</Label>
                <Input
                  type="number"
                  value={subgroupForm.imageWidth}
                  onChange={(e) => setSubgroupForm((f) => ({ ...f, imageWidth: parseInt(e.target.value) || 200 }))}
                />
              </div>
              <div className="space-y-2">
                <Label>Image Height</Label>
                <Input
                  type="number"
                  value={subgroupForm.imageHeight}
                  onChange={(e) => setSubgroupForm((f) => ({ ...f, imageHeight: parseInt(e.target.value) || 100 }))}
                />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setSubgroupDialogOpen(false)}>Cancel</Button>
            <Button onClick={saveSubgroup}>Add Subgroup</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Proxy Dialog */}
      <Dialog open={proxyDialogOpen} onOpenChange={setProxyDialogOpen}>
        <DialogContent className="sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editingProxy ? 'Edit Proxy' : 'Add Proxy'}</DialogTitle>
            <DialogDescription>
              {editingProxy ? 'Update proxy server configuration' : 'Add a new proxy server'}
            </DialogDescription>
          </DialogHeader>
          {renderProxyFormFields()}
          <DialogFooter>
            <Button variant="outline" onClick={() => setProxyDialogOpen(false)}>Cancel</Button>
            <Button onClick={saveProxy}>Save Proxy</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Bulk Upload Dialog */}
      <Dialog open={bulkUploadOpen} onOpenChange={setBulkUploadOpen}>
        <DialogContent className="sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>Bulk Upload Proxies</DialogTitle>
            <DialogDescription>Paste proxy data in CSV or JSON format</DialogDescription>
          </DialogHeader>
          <Tabs value={bulkUploadTab} onValueChange={setBulkUploadTab}>
            <TabsList>
              <TabsTrigger value="csv">CSV</TabsTrigger>
              <TabsTrigger value="json">JSON</TabsTrigger>
            </TabsList>
            <TabsContent value="csv" className="mt-3">
              <Textarea
                value={bulkUploadData}
                onChange={(e) => setBulkUploadData(e.target.value)}
                placeholder="Paste CSV data here..."
                rows={8}
                className="font-mono text-xs"
              />
              <details className="mt-2">
                <summary className="text-xs text-muted-foreground cursor-pointer">CSV Format Examples</summary>
                <Tabs defaultValue="vless" className="mt-2">
                  <TabsList className="h-7">
                    {PROTOCOLS.map((p) => (
                      <TabsTrigger key={p.value} value={p.value} className="text-[10px] px-2 h-5">
                        {p.label}
                      </TabsTrigger>
                    ))}
                  </TabsList>
                  {PROTOCOLS.map((p) => (
                    <TabsContent key={p.value} value={p.value} className="mt-1">
                      <pre className="text-[10px] bg-muted p-2 rounded-md overflow-x-auto max-h-32">
                        {csvExamples[p.value as keyof typeof csvExamples]}
                      </pre>
                    </TabsContent>
                  ))}
                </Tabs>
              </details>
            </TabsContent>
            <TabsContent value="json" className="mt-3">
              <Textarea
                value={bulkUploadData}
                onChange={(e) => setBulkUploadData(e.target.value)}
                placeholder="Paste JSON data here..."
                rows={8}
                className="font-mono text-xs"
              />
              <details className="mt-2">
                <summary className="text-xs text-muted-foreground cursor-pointer">JSON Format Examples</summary>
                <Tabs defaultValue="vless" className="mt-2">
                  <TabsList className="h-7">
                    {PROTOCOLS.map((p) => (
                      <TabsTrigger key={p.value} value={p.value} className="text-[10px] px-2 h-5">
                        {p.label}
                      </TabsTrigger>
                    ))}
                  </TabsList>
                  {PROTOCOLS.map((p) => (
                    <TabsContent key={p.value} value={p.value} className="mt-1">
                      <pre className="text-[10px] bg-muted p-2 rounded-md overflow-x-auto max-h-32">
                        {jsonExamples[p.value as keyof typeof jsonExamples]}
                      </pre>
                    </TabsContent>
                  ))}
                </Tabs>
              </details>
            </TabsContent>
          </Tabs>
          <DialogFooter>
            <Button variant="outline" onClick={() => setBulkUploadOpen(false)}>Cancel</Button>
            <Button onClick={processBulkUpload}>Upload</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Preset Edit Dialog (for detail view) */}
      <Dialog open={presetDialogOpen} onOpenChange={setPresetDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{editingPreset ? 'Edit Preset' : 'Add New Preset'}</DialogTitle>
            <DialogDescription>
              {editingPreset ? 'Update preset details' : 'Create a new proxy preset'}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Name</Label>
              <Input
                value={presetForm.name}
                onChange={(e) => setPresetForm((f) => ({ ...f, name: e.target.value }))}
                placeholder="Preset name"
              />
            </div>
            <div className="space-y-2">
              <Label>Description</Label>
              <Textarea
                value={presetForm.description}
                onChange={(e) => setPresetForm((f) => ({ ...f, description: e.target.value }))}
                placeholder="Preset description"
                rows={3}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label>Active</Label>
              <Switch
                checked={presetForm.isActive}
                onCheckedChange={(checked) => setPresetForm((f) => ({ ...f, isActive: checked }))}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setPresetDialogOpen(false)}>Cancel</Button>
            <Button onClick={savePreset}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation (for detail view) */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Preset</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure? This will permanently delete this preset and all its subgroups and proxies.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={deletePreset}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
