'use client'

import React, { useState, useMemo } from 'react'
import { toast } from 'sonner'

type LogType = 'normal' | 'paid' | 'referral'

interface LogEntry {
  id: string
  type: LogType
  user: string
  action: string
  timestamp: string
  ip: string
}

const mockActivityLogs: LogEntry[] = [
  { id: 'log_1', type: 'paid', user: 'Rafi Ahmed', action: 'Payment of ৳100.00 via bKash', timestamp: '2025-02-10 14:30', ip: '103.45.67.89' },
  { id: 'log_2', type: 'referral', user: 'Sadia Khan', action: 'Referred Tanvir Hasan — earned ৳5.00', timestamp: '2025-02-10 12:15', ip: '45.67.89.12' },
  { id: 'log_3', type: 'paid', user: 'Arif Hossain', action: 'Payment of ৳50.00 via Nagad', timestamp: '2025-02-09 18:45', ip: '67.89.12.34' },
  { id: 'log_4', type: 'normal', user: 'Nusrat Jahan', action: 'Subscription renewed — CoreX Pro', timestamp: '2025-02-09 10:00', ip: '89.12.34.56' },
  { id: 'log_5', type: 'referral', user: 'Imran Ali', action: 'Referred Farah Noor — earned ৳5.00', timestamp: '2025-02-08 22:30', ip: '12.34.56.78' },
  { id: 'log_6', type: 'paid', user: 'Tanvir Hasan', action: 'Payment of ৳150.00 via bKash', timestamp: '2025-02-08 16:00', ip: '34.56.78.91' },
  { id: 'log_7', type: 'normal', user: 'Farah Noor', action: 'Account settings updated', timestamp: '2025-02-07 09:15', ip: '56.78.91.23' },
  { id: 'log_8', type: 'referral', user: 'Rafi Ahmed', action: 'Referred Imran Ali — earned ৳5.00', timestamp: '2025-02-06 11:30', ip: '78.91.23.45' },
  { id: 'log_9', type: 'normal', user: 'Arif Hossain', action: 'Password changed', timestamp: '2025-02-05 14:00', ip: '91.23.45.67' },
  { id: 'log_10', type: 'paid', user: 'Sadia Khan', action: 'Payment of ৳29.99 via bKash', timestamp: '2025-02-04 08:45', ip: '23.45.67.89' },
]
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Checkbox } from '@/components/ui/checkbox'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import {
  ScrollText,
  Search,
  CalendarDays,
  Activity,
  User,
  DollarSign,
  Users,
  Filter,
  Trash2,
} from 'lucide-react'

function TypeBadge({ type }: { type: LogType }) {
  switch (type) {
    case 'normal':
      return (
        <Badge variant="secondary" className="gap-1">
          <Activity className="size-3" />
          Normal
        </Badge>
      )
    case 'paid':
      return (
        <Badge className="bg-emerald-500/15 text-emerald-400 border-emerald-500/30 hover:bg-emerald-500/25 gap-1">
          <DollarSign className="size-3" />
          Paid
        </Badge>
      )
    case 'referral':
      return (
        <Badge className="bg-amber-500/15 text-amber-400 border-amber-500/30 hover:bg-amber-500/25 gap-1">
          <Users className="size-3" />
          Referral
        </Badge>
      )
  }
}

function getRowClass(type: LogType): string {
  switch (type) {
    case 'paid':
      return 'bg-emerald-500/[0.03]'
    case 'referral':
      return 'bg-amber-500/[0.03]'
    default:
      return ''
  }
}

export function AdminLogs() {
  const [logs, setLogs] = useState<LogEntry[]>(() =>
    [...mockActivityLogs].sort((a, b) =>
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    )
  )
  const [typeFilter, setTypeFilter] = useState<string>('all')
  const [searchQuery, setSearchQuery] = useState('')
  const [dateFrom, setDateFrom] = useState('')
  const [dateTo, setDateTo] = useState('')
  const [activeTab, setActiveTab] = useState('all')

  // Bulk select
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set())
  const [bulkDeleteOpen, setBulkDeleteOpen] = useState(false)

  const toggleSelect = (id: string) => {
    setSelectedIds(prev => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  const toggleSelectAll = (ids: string[]) => {
    setSelectedIds(prev => {
      if (prev.size === ids.length) return new Set()
      return new Set(ids)
    })
  }

  const filteredLogs = useMemo(() => {
    let result = logs

    // Tab / type filter
    if (activeTab !== 'all') {
      result = result.filter((l) => l.type === activeTab)
    } else if (typeFilter !== 'all') {
      result = result.filter((l) => l.type === typeFilter)
    }

    // Search
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase()
      result = result.filter(
        (l) =>
          l.user.toLowerCase().includes(q) ||
          l.action.toLowerCase().includes(q) ||
          l.ip.toLowerCase().includes(q)
      )
    }

    // Date range
    if (dateFrom) {
      result = result.filter((l) => l.timestamp >= dateFrom)
    }
    if (dateTo) {
      result = result.filter((l) => l.timestamp <= dateTo + ' 23:59:59')
    }

    return result
  }, [logs, activeTab, typeFilter, searchQuery, dateFrom, dateTo])

  const filteredIds = filteredLogs.map((l) => l.id)

  // Stats
  const totalLogs = logs.length
  const normalCount = logs.filter((l) => l.type === 'normal').length
  const paidCount = logs.filter((l) => l.type === 'paid').length
  const referralCount = logs.filter((l) => l.type === 'referral').length

  const handleTabChange = (value: string) => {
    setActiveTab(value)
    setTypeFilter(value)
    setSelectedIds(new Set())
  }

  const handleBulkDelete = () => {
    const count = selectedIds.size
    setLogs((prev) => prev.filter((l) => !selectedIds.has(l.id)))
    toast.success(`${count} log entry/entries deleted`)
    setSelectedIds(new Set())
    setBulkDeleteOpen(false)
  }

  return (
    <div className="space-y-6">
      {/* Title */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Activity Logs</h1>
        <p className="text-muted-foreground text-sm mt-1">
          Monitor user activity, payments, and referral events
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card className="border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex size-10 items-center justify-center rounded-lg bg-primary/15">
                <ScrollText className="size-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{totalLogs}</p>
                <p className="text-xs text-muted-foreground">Total Logs</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex size-10 items-center justify-center rounded-lg bg-muted/50">
                <Activity className="size-5 text-muted-foreground" />
              </div>
              <div>
                <p className="text-2xl font-bold">{normalCount}</p>
                <p className="text-xs text-muted-foreground">Normal</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex size-10 items-center justify-center rounded-lg bg-emerald-500/15">
                <DollarSign className="size-5 text-emerald-400" />
              </div>
              <div>
                <p className="text-2xl font-bold">{paidCount}</p>
                <p className="text-xs text-muted-foreground">Paid</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex size-10 items-center justify-center rounded-lg bg-amber-500/15">
                <Users className="size-5 text-amber-400" />
              </div>
              <div>
                <p className="text-2xl font-bold">{referralCount}</p>
                <p className="text-xs text-muted-foreground">Referral</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filter Bar */}
      <Card className="border-border/50">
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="flex items-center gap-2 flex-1">
              <Filter className="size-4 text-muted-foreground shrink-0" />
              <Select value={typeFilter} onValueChange={(v) => { setTypeFilter(v); setActiveTab(v); }}>
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="Filter type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="normal">Normal</SelectItem>
                  <SelectItem value="paid">Paid</SelectItem>
                  <SelectItem value="referral">Referral</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-2 flex-1">
              <Search className="size-4 text-muted-foreground shrink-0" />
              <Input
                placeholder="Search user, action, IP..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1"
              />
            </div>
            <div className="flex items-center gap-2">
              <CalendarDays className="size-4 text-muted-foreground shrink-0" />
              <Input
                type="date"
                value={dateFrom}
                onChange={(e) => setDateFrom(e.target.value)}
                className="w-[150px]"
                placeholder="From"
              />
              <span className="text-muted-foreground text-sm">to</span>
              <Input
                type="date"
                value={dateTo}
                onChange={(e) => setDateTo(e.target.value)}
                className="w-[150px]"
                placeholder="To"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tabs & Table */}
      <Tabs value={activeTab} onValueChange={handleTabChange}>
        <TabsList>
          <TabsTrigger value="all" className="gap-1.5">
            <ScrollText className="size-3.5" />
            All
          </TabsTrigger>
          <TabsTrigger value="normal" className="gap-1.5">
            <Activity className="size-3.5" />
            Normal
          </TabsTrigger>
          <TabsTrigger value="paid" className="gap-1.5">
            <DollarSign className="size-3.5" />
            Paid
          </TabsTrigger>
          <TabsTrigger value="referral" className="gap-1.5">
            <Users className="size-3.5" />
            Referral
          </TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab}>
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Activity Log Entries</CardTitle>
              <CardDescription>
                Showing {filteredLogs.length} of {logs.length} entries
              </CardDescription>
            </CardHeader>
            <CardContent>
              {filteredLogs.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                  <ScrollText className="size-12 mb-3 opacity-30" />
                  <p className="font-medium">No logs found</p>
                  <p className="text-sm">Try adjusting your filters</p>
                </div>
              ) : (
                <>
                  {/* Bulk Action Bar */}
                  {selectedIds.size > 0 && (
                    <div className="flex items-center gap-3 p-3 mb-4 bg-muted/50 rounded-lg border">
                      <span className="text-sm font-medium">{selectedIds.size} selected</span>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setBulkDeleteOpen(true)}
                        className="gap-1 text-red-400 hover:text-red-300 hover:bg-red-500/10"
                      >
                        <Trash2 className="size-3.5" />
                        Delete Selected
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setSelectedIds(new Set())}
                      >
                        Clear selection
                      </Button>
                    </div>
                  )}
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-12">
                            <Checkbox
                              checked={selectedIds.size === filteredIds.length && filteredIds.length > 0}
                              onCheckedChange={() => toggleSelectAll(filteredIds)}
                            />
                          </TableHead>
                          <TableHead>Timestamp</TableHead>
                          <TableHead>User</TableHead>
                          <TableHead>Action</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>IP Address</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredLogs.map((log) => (
                          <TableRow key={log.id} className={getRowClass(log.type)}>
                            <TableCell>
                              <Checkbox
                                checked={selectedIds.has(log.id)}
                                onCheckedChange={() => toggleSelect(log.id)}
                              />
                            </TableCell>
                            <TableCell className="text-sm text-muted-foreground whitespace-nowrap font-mono text-xs">
                              {log.timestamp}
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <User className="size-3.5 text-muted-foreground" />
                                <span className="font-medium text-sm">{log.user}</span>
                              </div>
                            </TableCell>
                            <TableCell className="text-sm max-w-[300px]">
                              {log.action}
                            </TableCell>
                            <TableCell>
                              <TypeBadge type={log.type} />
                            </TableCell>
                            <TableCell className="font-mono text-xs text-muted-foreground">
                              {log.ip}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Bulk Delete Confirmation */}
      <AlertDialog open={bulkDeleteOpen} onOpenChange={setBulkDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Selected Logs</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete <strong>{selectedIds.size}</strong> log entry/entries?
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleBulkDelete} className="bg-red-600 hover:bg-red-700">
              Delete Selected
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
