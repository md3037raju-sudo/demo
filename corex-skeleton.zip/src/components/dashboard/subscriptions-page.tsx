'use client'

import React, { useState } from 'react'
import { useApp } from '@/app/page'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Separator } from '@/components/ui/separator'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  CreditCard,
  RefreshCw,
  Wallet,
  Monitor,
  AlertCircle,
  ArrowRight,
  Tag,
  X,
  History,
  Clock,
} from 'lucide-react'
import { toast } from 'sonner'
import { AnimateIn } from '@/components/shared/animate-in'

// ── Static Data ──────────────────────────────────────────────────────

interface StaticSub {
  id: string
  name: string
  plan: string
  status: 'active' | 'expired' | 'renewable'
  startDate: string
  expiryDate: string
  price: number
  devices: number
  durationLabel: string
  speed: string
  bandwidthLimit: string
  bandwidthType: 'unlimited' | 'limited'
  basePrice: number
  devicePricing: Record<number, number>
}

const initialHistorySubs: StaticSub[] = [
  {
    id: 'sub_h01',
    name: 'CoreX Standard',
    plan: '7 Days',
    status: 'renewable',
    startDate: '2025-01-10',
    expiryDate: '2025-01-17',
    price: 20.0,
    devices: 1,
    durationLabel: '7 Days',
    speed: '100 Mbps',
    bandwidthLimit: '50 GB',
    bandwidthType: 'limited',
    basePrice: 20,
    devicePricing: { 1: 100, 2: 180, 3: 250, 4: 310, 5: 360 },
  },
  {
    id: 'sub_h02',
    name: 'CoreX Premium',
    plan: '30 Days',
    status: 'expired',
    startDate: '2024-11-01',
    expiryDate: '2024-12-01',
    price: 50.0,
    devices: 2,
    durationLabel: '30 Days',
    speed: '200 Mbps',
    bandwidthLimit: 'Unlimited',
    bandwidthType: 'unlimited',
    basePrice: 50,
    devicePricing: { 1: 100, 2: 180, 3: 250, 4: 310, 5: 360 },
  },
]

function getStatusBadge(status: 'active' | 'expired' | 'renewable') {
  switch (status) {
    case 'active':
      return <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30 hover:bg-emerald-500/30">Active</Badge>
    case 'expired':
      return <Badge className="bg-red-500/20 text-red-400 border-red-500/30 hover:bg-red-500/30">Expired</Badge>
    case 'renewable':
      return <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30 hover:bg-amber-500/30">Renewable</Badge>
  }
}

function calculateDevicePrice(basePrice: number, devicePricing: Record<number, number>, devices: number): number {
  const pct = devicePricing[devices] ?? 100
  return (basePrice * pct) / 100
}

function getPerDeviceCost(totalPrice: number, devices: number): number {
  return devices > 0 ? totalPrice / devices : 0
}

function getDaysBeforeVanish(expiryDate: string): number | null {
  const expiry = new Date(expiryDate)
  const vanishDate = new Date(expiry)
  vanishDate.setDate(vanishDate.getDate() + 60)
  const now = new Date()
  const diff = Math.ceil((vanishDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24))
  return diff > 0 ? diff : null
}

// ── Component ────────────────────────────────────────────────────────

export function SubscriptionsPage() {
  const { user, navigate } = useApp()
  const [historySubs, setHistorySubs] = useState(initialHistorySubs)

  // Renew flow state
  const [renewDialogOpen, setRenewDialogOpen] = useState(false)
  const [renewingSub, setRenewingSub] = useState<StaticSub | null>(null)

  // Coupon state
  const [couponInput, setCouponInput] = useState('')
  const [couponDiscount, setCouponDiscount] = useState(0)
  const [couponError, setCouponError] = useState('')

  const balance = user?.balance ?? 0

  const activeCount = 2 // from overview static data
  const renewableCount = historySubs.filter((s) => s.status === 'renewable').length
  const totalSpent = historySubs.reduce((sum, s) => sum + s.price, 0) + 70 // + active subs

  const renewalPrice = renewingSub
    ? calculateDevicePrice(renewingSub.basePrice, renewingSub.devicePricing, renewingSub.devices)
    : 0
  const finalPrice = Math.max(0, renewalPrice - couponDiscount)

  const handleRenewClick = (sub: StaticSub) => {
    setRenewingSub(sub)
    setCouponInput('')
    setCouponDiscount(0)
    setCouponError('')
    setRenewDialogOpen(true)
  }

  const handleApplyCoupon = () => {
    if (!couponInput.trim()) {
      setCouponError('Please enter a coupon code')
      return
    }
    if (couponInput.trim().toUpperCase() === 'SAVE10') {
      const disc = Math.round(renewalPrice * 0.10 * 100) / 100
      setCouponDiscount(disc)
      setCouponError('')
      toast.success('Coupon applied!', { description: `You save ৳${disc.toFixed(2)} on this renewal.` })
    } else {
      setCouponError('Invalid coupon code')
      setCouponDiscount(0)
    }
  }

  const handleRemoveCoupon = () => {
    setCouponInput('')
    setCouponDiscount(0)
    setCouponError('')
  }

  const handleConfirmRenewal = () => {
    if (!renewingSub) return
    if (balance < finalPrice) return

    const now = new Date()
    const newExpiry = new Date(now)
    const daysMap: Record<string, number> = { '3 Days': 3, '7 Days': 7, '15 Days': 15, '30 Days': 30, '6 Months': 180, '1 Year': 365 }
    newExpiry.setDate(newExpiry.getDate() + (daysMap[renewingSub.durationLabel] ?? 30))
    const newExpiryStr = newExpiry.toISOString().split('T')[0]

    setHistorySubs((prev) =>
      prev.map((s) =>
        s.id === renewingSub.id
          ? { ...s, status: 'active' as const, expiryDate: newExpiryStr, startDate: now.toISOString().split('T')[0] }
          : s
      )
    )

    setRenewDialogOpen(false)
    setRenewingSub(null)
    setCouponInput('')
    setCouponDiscount(0)
    setCouponError('')

    const discountMsg = couponDiscount > 0 ? ` ৳${couponDiscount.toFixed(2)} coupon discount applied.` : ''
    toast.success('Subscription renewed!', {
      description: `${renewingSub.name} has been reactivated. New expiry: ${newExpiry.toLocaleDateString()}. ৳${finalPrice.toFixed(2)} deducted.${discountMsg}`,
    })
  }

  const handleCancelRenew = () => {
    setRenewDialogOpen(false)
    setRenewingSub(null)
    setCouponInput('')
    setCouponDiscount(0)
    setCouponError('')
  }

  const stats = [
    {
      title: 'Total Spent',
      value: `৳${totalSpent.toFixed(0)}`,
      icon: Wallet,
      color: 'text-emerald-500',
      bg: 'bg-emerald-500/10',
    },
    {
      title: 'Active',
      value: activeCount,
      icon: CreditCard,
      color: 'text-emerald-500',
      bg: 'bg-emerald-500/10',
    },
    {
      title: 'Renewable',
      value: renewableCount,
      icon: RefreshCw,
      color: 'text-amber-500',
      bg: 'bg-amber-500/10',
    },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Subscription History</h2>
        <p className="text-muted-foreground">
          Expired subscriptions are kept for 60 days, then permanently removed. Renewable ones can be renewed anytime within this window.
        </p>
      </div>

      {/* Stats */}
      <div className="grid gap-4 sm:grid-cols-3">
        {stats.map((stat, i) => (
          <AnimateIn key={stat.title} type="slide-up" delay={i * 60}>
            <Card className="p-4">
              <div className="flex items-center gap-3">
                <div className={`flex size-10 items-center justify-center rounded-lg ${stat.bg}`}>
                  <stat.icon className={`size-5 ${stat.color}`} />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">{stat.title}</p>
                  <p className="text-xl font-bold">{stat.value}</p>
                </div>
              </div>
            </Card>
          </AnimateIn>
        ))}
      </div>

      {/* History Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <History className="size-5 text-muted-foreground" />
            Expired &amp; Renewable
          </CardTitle>
          <CardDescription>
            Subscriptions past their expiry date. Renewable within 60 days.
          </CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          {historySubs.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Plan</TableHead>
                  <TableHead>Devices</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Expired On</TableHead>
                  <TableHead>Price</TableHead>
                  <TableHead>Vanishes In</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {historySubs.map((sub) => {
                  const daysLeft = getDaysBeforeVanish(sub.expiryDate)
                  return (
                    <TableRow key={sub.id}>
                      <TableCell className="font-medium">{sub.name}</TableCell>
                      <TableCell>{sub.plan}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1.5">
                          <Monitor className="size-3.5 text-muted-foreground" />
                          <span>{sub.devices}</span>
                        </div>
                      </TableCell>
                      <TableCell>{getStatusBadge(sub.status)}</TableCell>
                      <TableCell>{sub.expiryDate}</TableCell>
                      <TableCell className="font-medium">৳{sub.price.toFixed(2)}</TableCell>
                      <TableCell>
                        {daysLeft !== null ? (
                          <Badge className={`text-xs ${
                            daysLeft <= 7
                              ? 'bg-red-500/20 text-red-400 border-red-500/30'
                              : daysLeft <= 30
                                ? 'bg-amber-500/20 text-amber-400 border-amber-500/30'
                                : 'bg-muted text-muted-foreground border-border'
                          }`}>
                            {daysLeft}d left
                          </Badge>
                        ) : (
                          <Badge className="bg-red-500/20 text-red-400 border-red-500/30">
                            Vanished
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="outline"
                          size="sm"
                          className="gap-1.5"
                          onClick={() => handleRenewClick(sub)}
                          disabled={sub.status === 'expired' && daysLeft === null}
                        >
                          <RefreshCw className="size-3.5" />
                          Renew
                        </Button>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          ) : (
            <div className="py-12 text-center">
              <History className="mx-auto mb-3 size-12 text-muted-foreground/50" />
              <p className="text-muted-foreground">No expired subscriptions in the last 60 days.</p>
              <p className="text-xs text-muted-foreground mt-1">Expired records are automatically removed after 60 days.</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* ── Renew Dialog ── */}
      <Dialog open={renewDialogOpen} onOpenChange={(open) => { if (!open) handleCancelRenew() }}>
        <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <RefreshCw className="size-5 text-primary" />
              Renew Subscription
            </DialogTitle>
            <DialogDescription>
              Reactivate your subscription with the same plan and device configuration. Your expiry date will be extended from today.
            </DialogDescription>
          </DialogHeader>

          {renewingSub && (
            <div className="space-y-4 py-2">
              <Card className="border-primary/20 bg-primary/5">
                <CardContent className="p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-lg">{renewingSub.name}</span>
                    <Badge variant="outline">{renewingSub.durationLabel}</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">Reactivate with the same plan settings</p>
                  <Separator />
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div className="text-muted-foreground">Duration</div>
                    <div className="text-right font-medium">{renewingSub.durationLabel}</div>
                    <div className="text-muted-foreground">Speed</div>
                    <div className="text-right font-medium">{renewingSub.speed}</div>
                    <div className="text-muted-foreground">Bandwidth</div>
                    <div className="text-right font-medium">
                      <Badge variant="outline" className={`text-xs ${renewingSub.bandwidthType === 'unlimited' ? 'border-emerald-500/30 text-emerald-400' : ''}`}>
                        {renewingSub.bandwidthLimit}
                      </Badge>
                    </div>
                    <div className="text-muted-foreground">Devices</div>
                    <div className="text-right font-medium">
                      {renewingSub.devices} device{renewingSub.devices > 1 ? 's' : ''}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 pt-1 text-xs text-muted-foreground">
                    <Clock className="size-3.5" />
                    <span>New expiry will be calculated from today</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardContent className="p-4 space-y-2.5">
                  <div className="flex items-center gap-2 mb-1">
                    <Wallet className="size-4 text-primary" />
                    <span className="font-medium text-sm">Price Breakdown</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Base price (1 device)</span>
                    <span className="font-medium">৳{calculateDevicePrice(renewingSub.basePrice, renewingSub.devicePricing, 1).toFixed(2)}</span>
                  </div>
                  {renewingSub.devices > 1 && (
                    <>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">
                          Device multiplier ({renewingSub.devices} devices — {renewingSub.devicePricing[renewingSub.devices]}% of base)
                        </span>
                        <span className="font-medium">৳{renewalPrice.toFixed(2)}</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">Per-device cost</span>
                        <span className="font-medium">৳{getPerDeviceCost(renewalPrice, renewingSub.devices).toFixed(2)}</span>
                      </div>
                      <Separator />
                    </>
                  )}
                  <div className="flex items-center justify-between text-sm">
                    <span className="font-medium">Renewal price</span>
                    <span className="font-bold text-lg">৳{renewalPrice.toFixed(2)}</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardContent className="p-4 space-y-3">
                  <div className="flex items-center gap-2">
                    <Tag className="size-4 text-primary" />
                    <span className="font-medium text-sm">Have a coupon code?</span>
                  </div>
                  {couponDiscount > 0 ? (
                    <div className="flex items-center justify-between rounded-lg border border-emerald-500/30 bg-emerald-500/10 px-3 py-2">
                      <div className="flex items-center gap-2">
                        <Tag className="size-4 text-emerald-400" />
                        <div>
                          <code className="font-mono text-sm font-bold text-emerald-400">{couponInput}</code>
                          <p className="text-xs text-emerald-300">Coupon applied! You save ৳{couponDiscount.toFixed(2)}</p>
                        </div>
                      </div>
                      <Button variant="ghost" size="icon" className="size-7 text-muted-foreground hover:text-red-400" onClick={handleRemoveCoupon}>
                        <X className="size-3.5" />
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <div className="flex gap-2">
                        <Input placeholder="Enter coupon code (try SAVE10)" value={couponInput} onChange={(e) => { setCouponInput(e.target.value.toUpperCase()); setCouponError(''); }} className="font-mono" />
                        <Button variant="outline" className="shrink-0 gap-1.5" onClick={handleApplyCoupon} disabled={!couponInput.trim()}>
                          <Tag className="size-3.5" /> Apply
                        </Button>
                      </div>
                      {couponError && <p className="text-xs text-red-400">{couponError}</p>}
                    </div>
                  )}
                  {couponDiscount > 0 && (
                    <div className="flex items-center justify-between text-sm pt-1">
                      <span className="text-muted-foreground">Coupon Discount</span>
                      <span className="font-semibold text-emerald-400">-৳{couponDiscount.toFixed(2)}</span>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card className={`border-border/50 ${balance < finalPrice ? 'border-red-500/30 bg-red-500/5' : 'border-emerald-500/30 bg-emerald-500/5'}`}>
                <CardContent className="p-4 space-y-2.5">
                  {couponDiscount > 0 && (
                    <>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">Original Price</span>
                        <span className="line-through text-muted-foreground">৳{renewalPrice.toFixed(2)}</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">Coupon Discount</span>
                        <span className="font-semibold text-emerald-400">-৳{couponDiscount.toFixed(2)}</span>
                      </div>
                    </>
                  )}
                  <div className="flex items-center justify-between">
                    <span className="font-semibold">Final Price</span>
                    <span className="text-xl font-bold">৳{finalPrice.toFixed(2)}</span>
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Current Balance</span>
                    <span className="font-semibold">৳{balance.toFixed(2)}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">After Renewal</span>
                    <span className={`font-semibold ${balance < finalPrice ? 'text-red-400' : 'text-emerald-400'}`}>
                      ৳{(balance - finalPrice).toFixed(2)}
                    </span>
                  </div>
                  {balance < finalPrice && (
                    <div className="mt-3 flex items-start gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/20">
                      <AlertCircle className="size-4 text-red-400 shrink-0 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium text-red-400">Insufficient Balance</p>
                        <p className="text-xs text-muted-foreground mt-1">
                          You need ৳{(finalPrice - balance).toFixed(2)} more. Add funds to your balance to complete this renewal.
                        </p>
                        <Button variant="outline" size="sm" className="mt-2 gap-1 border-red-500/30 text-red-400 hover:bg-red-500/10 hover:text-red-300" onClick={() => { setRenewDialogOpen(false); navigate('dashboard/payments') }}>
                          Go to Payments <ArrowRight className="size-3" />
                        </Button>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          )}

          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="ghost" onClick={handleCancelRenew}>Cancel</Button>
            {renewingSub && balance >= finalPrice && (
              <Button className="gap-1.5" onClick={handleConfirmRenewal}>
                <RefreshCw className="size-4" />
                Confirm Renewal — ৳{finalPrice.toFixed(2)}
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
