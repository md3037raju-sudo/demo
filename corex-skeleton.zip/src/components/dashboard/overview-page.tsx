'use client'

import React, { useState } from 'react'
import { useApp } from '@/app/page'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Separator } from '@/components/ui/separator'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  CreditCard,
  Smartphone,
  Wallet,
  Users,
  Settings,
  ShoppingCart,
  Check,
  Zap,
  Globe,
  Monitor,
  AlertCircle,
  ArrowRight,
  Tag,
  X,
  Star,
  Clock,
  Wifi,
  HardDrive,
  ChevronRight,
  Sparkles,
  CalendarPlus,
} from 'lucide-react'
import { toast } from 'sonner'
import { AnimateIn } from '@/components/shared/animate-in'

// ── Static Data ──────────────────────────────────────────────────────

interface StaticSubscription {
  id: string
  name: string
  plan: string
  status: 'active' | 'expired' | 'renewable'
  startDate: string
  expiryDate: string
  price: number
  devices: number
  bandwidthUsed: number
  bandwidthLimit: number
  deepLink: string
}

const initialSubscriptions: StaticSubscription[] = [
  {
    id: 'sub_001',
    name: 'CoreX Premium',
    plan: '30 Days',
    status: 'active',
    startDate: '2025-01-15',
    expiryDate: '2026-03-15',
    price: 50.0,
    devices: 1,
    bandwidthUsed: 12,
    bandwidthLimit: 100,
    deepLink: 'corex://configure/sub_001',
  },
  {
    id: 'sub_002',
    name: 'CoreX Standard',
    plan: '7 Days',
    status: 'active',
    startDate: '2025-02-20',
    expiryDate: '2026-04-20',
    price: 20.0,
    devices: 2,
    bandwidthUsed: 3,
    bandwidthLimit: 50,
    deepLink: 'corex://configure/sub_002',
  },
]

interface StaticPlan {
  id: string
  name: string
  duration: string
  durationLabel: string
  description: string
  speed: string
  bandwidthLimit: string
  bandwidthType: 'unlimited' | 'limited'
  basePrice: number
  devicePricing: Record<number, number>
  isFeatured: boolean
  isActive: boolean
}

const staticPlans: StaticPlan[] = [
  {
    id: 'plan_3d_basic',
    name: 'CoreX Basic',
    duration: '3d',
    durationLabel: '3 Days',
    description: 'Quick access plan for short-term needs',
    speed: '50 Mbps',
    bandwidthLimit: '10 GB',
    bandwidthType: 'limited',
    basePrice: 10,
    devicePricing: { 1: 100, 2: 180, 3: 250, 4: 310, 5: 360 },
    isFeatured: false,
    isActive: true,
  },
  {
    id: 'plan_7d_standard',
    name: 'CoreX Standard',
    duration: '7d',
    durationLabel: '7 Days',
    description: 'Our most popular weekly plan with great value',
    speed: '100 Mbps',
    bandwidthLimit: '50 GB',
    bandwidthType: 'limited',
    basePrice: 20,
    devicePricing: { 1: 100, 2: 180, 3: 250, 4: 310, 5: 360 },
    isFeatured: true,
    isActive: true,
  },
  {
    id: 'plan_30d_premium',
    name: 'CoreX Premium',
    duration: '30d',
    durationLabel: '30 Days',
    description: 'Full-featured monthly plan with unlimited bandwidth',
    speed: '200 Mbps',
    bandwidthLimit: 'Unlimited',
    bandwidthType: 'unlimited',
    basePrice: 50,
    devicePricing: { 1: 100, 2: 180, 3: 250, 4: 310, 5: 360 },
    isFeatured: true,
    isActive: true,
  },
  {
    id: 'plan_6m_pro',
    name: 'CoreX Pro',
    duration: '6m',
    durationLabel: '6 Months',
    description: 'Long-term plan with maximum savings',
    speed: '300 Mbps',
    bandwidthLimit: 'Unlimited',
    bandwidthType: 'unlimited',
    basePrice: 250,
    devicePricing: { 1: 100, 2: 180, 3: 250, 4: 310, 5: 360 },
    isFeatured: false,
    isActive: true,
  },
]

const DURATION_ORDER = ['3d', '7d', '15d', '30d', '6m', '1y']

function calculateDevicePrice(basePrice: number, devicePricing: Record<number, number>, devices: number): number {
  const pct = devicePricing[devices] ?? 100
  return (basePrice * pct) / 100
}

function getPerDeviceCost(totalPrice: number, devices: number): number {
  return devices > 0 ? totalPrice / devices : 0
}

function getSavingsPercent(basePrice: number, devicePricing: Record<number, number>, devices: number): number {
  if (devices <= 1) return 0
  const singlePrice = calculateDevicePrice(basePrice, devicePricing, 1)
  const multiPricePerDevice = getPerDeviceCost(calculateDevicePrice(basePrice, devicePricing, devices), devices)
  if (singlePrice === 0) return 0
  return Math.round(((singlePrice - multiPricePerDevice) / singlePrice) * 100)
}

function calculateNewExpiry(currentExpiry: string | Date, durationLabel: string): Date {
  const base = typeof currentExpiry === 'string' ? new Date(currentExpiry) : currentExpiry
  const result = new Date(base)
  const map: Record<string, number> = {
    '3 Days': 3, '7 Days': 7, '15 Days': 15, '30 Days': 30,
    '6 Months': 180, '1 Year': 365,
  }
  result.setDate(result.getDate() + (map[durationLabel] ?? 30))
  return result
}

// ── Component ────────────────────────────────────────────────────────

export function OverviewPage() {
  const { user, navigate } = useApp()
  const [subscriptions, setSubscriptions] = useState<StaticSubscription[]>(initialSubscriptions)

  const [configDialogOpen, setConfigDialogOpen] = useState(false)
  const [selectedSubId, setSelectedSubId] = useState<string | null>(null)

  // Purchase flow state
  const [purchaseDialogOpen, setPurchaseDialogOpen] = useState(false)
  const [confirmDialogOpen, setConfirmDialogOpen] = useState(false)
  const [selectedPlanId, setSelectedPlanId] = useState<string | null>(null)
  const [selectedDevices, setSelectedDevices] = useState(1)

  // Extend flow state
  const [extendDialogOpen, setExtendDialogOpen] = useState(false)
  const [extendingSub, setExtendingSub] = useState<StaticSubscription | null>(null)

  // Coupon state
  const [couponInput, setCouponInput] = useState('')
  const [couponDiscount, setCouponDiscount] = useState(0)
  const [couponError, setCouponError] = useState('')

  const activeSubsList = subscriptions.filter((s) => s.status === 'active')
  const activeSubscriptions = activeSubsList.length
  const totalSpent = subscriptions.reduce((sum, s) => sum + s.price, 0)
  const balance = user?.balance ?? 0
  const referralCount = 0

  const handleConfigure = (subId: string) => {
    setSelectedSubId(subId)
    setConfigDialogOpen(true)
  }

  const handleOpenCoreX = () => {
    if (selectedSubId) {
      window.location.href = `corex://configure/${selectedSubId}`
    }
    setConfigDialogOpen(false)
  }

  // ── Extend handlers ──
  const handleExtendClick = (sub: StaticSubscription) => {
    setExtendingSub(sub)
    setCouponInput('')
    setCouponDiscount(0)
    setCouponError('')
    setExtendDialogOpen(true)
  }

  const extendPlan = extendingSub ? staticPlans.find((p) => p.name === extendingSub.name) ?? null : null
  const extendPrice = extendingSub && extendPlan
    ? calculateDevicePrice(extendPlan.basePrice, extendPlan.devicePricing, extendingSub.devices)
    : 0
  const extendFinalPrice = Math.max(0, extendPrice - couponDiscount)
  const newExpiryDate = extendingSub && extendPlan
    ? calculateNewExpiry(extendingSub.expiryDate, extendPlan.durationLabel)
    : null

  const handleExtendApplyCoupon = () => {
    if (!couponInput.trim()) {
      setCouponError('Please enter a coupon code')
      return
    }
    // Simulate coupon: "SAVE10" gives 10% off
    if (couponInput.trim().toUpperCase() === 'SAVE10') {
      const disc = Math.round(extendPrice * 0.10 * 100) / 100
      setCouponDiscount(disc)
      setCouponError('')
      toast.success('Coupon applied!', { description: `You save ৳${disc.toFixed(2)} on this extension.` })
    } else {
      setCouponError('Invalid coupon code')
      setCouponDiscount(0)
    }
  }

  const handleExtendRemoveCoupon = () => {
    setCouponInput('')
    setCouponDiscount(0)
    setCouponError('')
  }

  const handleConfirmExtend = () => {
    if (!extendingSub || !extendPlan) return
    if (balance < extendFinalPrice) return

    const newExpiry = calculateNewExpiry(extendingSub.expiryDate, extendPlan.durationLabel)
    const newExpiryStr = newExpiry.toISOString().split('T')[0]

    setSubscriptions((prev) =>
      prev.map((s) =>
        s.id === extendingSub.id
          ? { ...s, expiryDate: newExpiryStr, price: s.price + extendPrice }
          : s
      )
    )

    setExtendDialogOpen(false)
    setExtendingSub(null)
    setCouponInput('')
    setCouponDiscount(0)
    setCouponError('')

    const discountMsg = couponDiscount > 0 ? ` ৳${couponDiscount.toFixed(2)} coupon discount applied.` : ''
    toast.success('Subscription extended!', {
      description: `${extendingSub.name} has been extended to ${newExpiry.toLocaleDateString()}. ৳${extendFinalPrice.toFixed(2)} deducted.${discountMsg}`,
    })
  }

  const handleCancelExtend = () => {
    setExtendDialogOpen(false)
    setExtendingSub(null)
    setCouponInput('')
    setCouponDiscount(0)
    setCouponError('')
  }

  // ── Purchase flow ──
  const selectedPlan = staticPlans.find((p) => p.id === selectedPlanId) ?? null

  const activePlans = staticPlans.filter((p) => p.isActive)
  const plansByDuration: Record<string, StaticPlan[]> = {}
  for (const plan of activePlans) {
    if (!plansByDuration[plan.duration]) plansByDuration[plan.duration] = []
    plansByDuration[plan.duration].push(plan)
  }

  const defaultDurationTab = (() => {
    for (const d of DURATION_ORDER) {
      if (plansByDuration[d] && plansByDuration[d].length > 0) return d
    }
    return '30d'
  })()

  const totalPrice = selectedPlan
    ? calculateDevicePrice(selectedPlan.basePrice, selectedPlan.devicePricing, selectedDevices)
    : 0
  const perDeviceCost = selectedPlan
    ? getPerDeviceCost(totalPrice, selectedDevices)
    : 0
  const savingsPercent = selectedPlan
    ? getSavingsPercent(selectedPlan.basePrice, selectedPlan.devicePricing, selectedDevices)
    : 0

  const finalPrice = Math.max(0, totalPrice - couponDiscount)

  const handleSelectPlan = (planId: string) => {
    setSelectedPlanId(planId)
    setSelectedDevices(1)
    setCouponInput('')
    setCouponDiscount(0)
    setCouponError('')
  }

  const handleProceedToCheckout = () => {
    if (!selectedPlanId) return
    setPurchaseDialogOpen(false)
    setConfirmDialogOpen(true)
  }

  const handleBackToPlans = () => {
    setConfirmDialogOpen(false)
    setPurchaseDialogOpen(true)
  }

  const handleApplyCoupon = () => {
    if (!couponInput.trim()) {
      setCouponError('Please enter a coupon code')
      return
    }
    if (!selectedPlan) return
    if (couponInput.trim().toUpperCase() === 'SAVE10') {
      const disc = Math.round(totalPrice * 0.10 * 100) / 100
      setCouponDiscount(disc)
      setCouponError('')
      toast.success('Coupon applied!', { description: `You save ৳${disc.toFixed(2)} on this purchase.` })
    } else {
      setCouponError('Invalid coupon code')
      setCouponDiscount(0)
    }
  }

  const handleRemoveCoupon = () => {
    setCouponInput('')
    setCouponDiscount(0)
    setCouponError('')
  }

  const handleConfirmPurchase = () => {
    if (!selectedPlan) return
    if (balance < finalPrice) return

    const now = new Date()
    const expiry = calculateNewExpiry(now, selectedPlan.durationLabel)
    const bwLimit = selectedPlan.bandwidthType === 'unlimited' ? 9999 : parseInt(selectedPlan.bandwidthLimit.replace(/[^0-9]/g, '')) || 0

    const newSub: StaticSubscription = {
      id: `sub_${Date.now()}`,
      name: selectedPlan.name,
      plan: selectedPlan.durationLabel,
      status: 'active',
      startDate: now.toISOString().split('T')[0],
      expiryDate: expiry.toISOString().split('T')[0],
      price: totalPrice,
      devices: selectedDevices,
      bandwidthUsed: 0,
      bandwidthLimit: bwLimit,
      deepLink: `corex://configure/sub_${Date.now()}`,
    }

    setSubscriptions((prev) => [...prev, newSub])

    setConfirmDialogOpen(false)
    setSelectedPlanId(null)
    setSelectedDevices(1)
    setCouponInput('')
    setCouponDiscount(0)
    setCouponError('')

    const discountMsg = couponDiscount > 0 ? ` ৳${couponDiscount.toFixed(2)} coupon discount applied.` : ''
    toast.success('Subscription purchased!', {
      description: `${selectedPlan.name} (${selectedPlan.durationLabel}, ${selectedDevices} device${selectedDevices > 1 ? 's' : ''}) has been activated. ৳${finalPrice.toFixed(2)} deducted from your balance.${discountMsg}`,
    })
  }

  const handleCancelPurchase = () => {
    setConfirmDialogOpen(false)
    setSelectedPlanId(null)
    setSelectedDevices(1)
    setCouponInput('')
    setCouponDiscount(0)
    setCouponError('')
  }

  const stats = [
    {
      title: 'Total Spent',
      value: `৳${totalSpent.toFixed(2)}`,
      icon: Wallet,
      color: 'text-emerald-400',
      bg: 'bg-emerald-500/10',
    },
    {
      title: 'Active',
      value: activeSubscriptions,
      icon: CreditCard,
      color: 'text-emerald-400',
      bg: 'bg-emerald-500/10',
    },
    {
      title: 'Balance',
      value: `৳${balance.toFixed(2)}`,
      icon: Smartphone,
      color: 'text-teal-400',
      bg: 'bg-teal-500/10',
    },
    {
      title: 'Referrals',
      value: referralCount,
      icon: Users,
      color: 'text-teal-400',
      bg: 'bg-teal-500/10',
    },
  ]

  return (
    <div className="space-y-6">
      {/* Welcome + Buy Button */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold">
            Welcome back, {user?.name?.split(' ')[0]}
          </h2>
          <p className="text-muted-foreground">
            Here&apos;s an overview of your CoreX account.
          </p>
        </div>
        <Button
          size="lg"
          className="gap-2 shadow-lg shadow-primary/20"
          onClick={() => {
            setSelectedPlanId(null)
            setSelectedDevices(1)
            setPurchaseDialogOpen(true)
          }}
        >
          <ShoppingCart className="size-4" />
          Buy Subscription
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat, i) => (
          <AnimateIn key={stat.title} type="slide-up" delay={i * 60}>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  {stat.title}
                </CardTitle>
                <div className={`rounded-lg p-2 ${stat.bg}`}>
                  <stat.icon className={`size-4 ${stat.color}`} />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value}</div>
              </CardContent>
            </Card>
          </AnimateIn>
        ))}
      </div>

      {/* Active Subscriptions Table */}
      <Card>
        <CardHeader>
          <CardTitle>Active Subscriptions</CardTitle>
        </CardHeader>
        <CardContent>
          {activeSubsList.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Plan</TableHead>
                  <TableHead>Devices</TableHead>
                  <TableHead>Start Date</TableHead>
                  <TableHead>Expiry Date</TableHead>
                  <TableHead>Price</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {activeSubsList.map((sub) => {
                  const hasMatchingPlan = staticPlans.some((p) => p.name === sub.name)
                  return (
                    <TableRow key={sub.id}>
                      <TableCell className="font-medium">{sub.name}</TableCell>
                      <TableCell>{sub.plan}</TableCell>
                      <TableCell>{sub.devices}</TableCell>
                      <TableCell>{sub.startDate}</TableCell>
                      <TableCell>{sub.expiryDate}</TableCell>
                      <TableCell>৳{sub.price.toFixed(2)}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1.5">
                          <Button
                            variant="outline"
                            size="sm"
                            className="gap-1.5"
                            onClick={() => handleConfigure(sub.id)}
                          >
                            <Settings className="size-3.5" />
                            Configure
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="gap-1.5"
                            onClick={() => handleExtendClick(sub)}
                            disabled={!hasMatchingPlan}
                          >
                            <CalendarPlus className="size-3.5" />
                            Extend
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          ) : (
            <div className="py-8 text-center">
              <CreditCard className="mx-auto mb-3 size-10 text-muted-foreground/50" />
              <p className="text-sm text-muted-foreground">No active subscriptions</p>
              <p className="text-xs text-muted-foreground mt-1">Purchase a plan to get started!</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Deep Link Dialog */}
      <Dialog open={configDialogOpen} onOpenChange={setConfigDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Open CoreX App?</DialogTitle>
            <DialogDescription>
              This will open the CoreX application to configure your
              subscription. Make sure CoreX is installed on your device.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setConfigDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleOpenCoreX}>
              Open CoreX
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── Extend Subscription Dialog ── */}
      <Dialog open={extendDialogOpen} onOpenChange={(open) => { if (!open) handleCancelExtend() }}>
        <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CalendarPlus className="size-5 text-primary" />
              Extend Subscription
            </DialogTitle>
            <DialogDescription>
              Extend your active subscription by adding more time. Your new expiry date will be calculated from the current expiry.
            </DialogDescription>
          </DialogHeader>

          {extendingSub && extendPlan && (
            <div className="space-y-4 py-2">
              <Card className="border-primary/20 bg-primary/5">
                <CardContent className="p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-lg">{extendingSub.name}</span>
                    <Badge variant="outline">{extendPlan.durationLabel}</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">{extendPlan.description}</p>
                  <Separator />
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div className="text-muted-foreground">Duration</div>
                    <div className="text-right font-medium">{extendPlan.durationLabel}</div>
                    <div className="text-muted-foreground">Speed</div>
                    <div className="text-right font-medium">{extendPlan.speed}</div>
                    <div className="text-muted-foreground">Bandwidth</div>
                    <div className="text-right font-medium">
                      <Badge
                        variant="outline"
                        className={`text-xs ${
                          extendPlan.bandwidthType === 'unlimited'
                            ? 'border-emerald-500/30 text-emerald-400'
                            : ''
                        }`}
                      >
                        {extendPlan.bandwidthLimit}
                      </Badge>
                    </div>
                    <div className="text-muted-foreground">Devices</div>
                    <div className="text-right font-medium">
                      {extendingSub.devices} device{extendingSub.devices > 1 ? 's' : ''}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 pt-1 text-xs text-muted-foreground">
                    <Clock className="size-3.5" />
                    <span>Current expiry: <strong className="text-foreground">{new Date(extendingSub.expiryDate).toLocaleDateString()}</strong></span>
                  </div>
                  {newExpiryDate && (
                    <div className="flex items-center gap-2 text-xs text-emerald-400">
                      <CalendarPlus className="size-3.5" />
                      <span>New expiry after extend: <strong>{newExpiryDate.toLocaleDateString()}</strong></span>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardContent className="p-4 space-y-2.5">
                  <div className="flex items-center gap-2 mb-1">
                    <Wallet className="size-4 text-primary" />
                    <span className="font-medium text-sm">Price Breakdown</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Base price (1 device)</span>
                    <span className="font-medium">৳{calculateDevicePrice(extendPlan.basePrice, extendPlan.devicePricing, 1).toFixed(2)}</span>
                  </div>
                  {extendingSub.devices > 1 && (
                    <>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">
                          Device multiplier ({extendingSub.devices} devices — {extendPlan.devicePricing[extendingSub.devices]}% of base)
                        </span>
                        <span className="font-medium">৳{extendPrice.toFixed(2)}</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">Per-device cost</span>
                        <span className="font-medium">৳{getPerDeviceCost(extendPrice, extendingSub.devices).toFixed(2)}</span>
                      </div>
                      <Separator />
                    </>
                  )}
                  <div className="flex items-center justify-between text-sm">
                    <span className="font-medium">Extend price</span>
                    <span className="font-bold text-lg">৳{extendPrice.toFixed(2)}</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardContent className="p-4 space-y-3">
                  <div className="flex items-center gap-2">
                    <Tag className="size-4 text-primary" />
                    <span className="font-medium text-sm">Have a coupon code?</span>
                  </div>
                  {couponDiscount > 0 ? (
                    <div className="flex items-center justify-between rounded-lg border border-emerald-500/30 bg-emerald-500/10 px-3 py-2">
                      <div className="flex items-center gap-2">
                        <Tag className="size-4 text-emerald-400" />
                        <div>
                          <code className="font-mono text-sm font-bold text-emerald-400">{couponInput}</code>
                          <p className="text-xs text-emerald-300">Coupon applied! You save ৳{couponDiscount.toFixed(2)}</p>
                        </div>
                      </div>
                      <Button variant="ghost" size="icon" className="size-7 text-muted-foreground hover:text-red-400" onClick={handleExtendRemoveCoupon}>
                        <X className="size-3.5" />
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <div className="flex gap-2">
                        <Input
                          placeholder="Enter coupon code (try SAVE10)"
                          value={couponInput}
                          onChange={(e) => { setCouponInput(e.target.value.toUpperCase()); setCouponError(''); }}
                          className="font-mono"
                        />
                        <Button variant="outline" className="shrink-0 gap-1.5" onClick={handleExtendApplyCoupon} disabled={!couponInput.trim()}>
                          <Tag className="size-3.5" />
                          Apply
                        </Button>
                      </div>
                      {couponError && <p className="text-xs text-red-400">{couponError}</p>}
                    </div>
                  )}
                  {couponDiscount > 0 && (
                    <div className="flex items-center justify-between text-sm pt-1">
                      <span className="text-muted-foreground">Coupon Discount</span>
                      <span className="font-semibold text-emerald-400">-৳{couponDiscount.toFixed(2)}</span>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card className={`border-border/50 ${balance < extendFinalPrice ? 'border-red-500/30 bg-red-500/5' : 'border-emerald-500/30 bg-emerald-500/5'}`}>
                <CardContent className="p-4 space-y-2.5">
                  {couponDiscount > 0 && (
                    <>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">Original Price</span>
                        <span className="line-through text-muted-foreground">৳{extendPrice.toFixed(2)}</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">Coupon Discount</span>
                        <span className="font-semibold text-emerald-400">-৳{couponDiscount.toFixed(2)}</span>
                      </div>
                    </>
                  )}
                  <div className="flex items-center justify-between">
                    <span className="font-semibold">Final Price</span>
                    <span className="text-xl font-bold">৳{extendFinalPrice.toFixed(2)}</span>
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Current Balance</span>
                    <span className="font-semibold">৳{balance.toFixed(2)}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">After Extension</span>
                    <span className={`font-semibold ${balance < extendFinalPrice ? 'text-red-400' : 'text-emerald-400'}`}>
                      ৳{(balance - extendFinalPrice).toFixed(2)}
                    </span>
                  </div>
                  {balance < extendFinalPrice && (
                    <div className="mt-3 flex items-start gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/20">
                      <AlertCircle className="size-4 text-red-400 shrink-0 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium text-red-400">Insufficient Balance</p>
                        <p className="text-xs text-muted-foreground mt-1">
                          You need ৳{(extendFinalPrice - balance).toFixed(2)} more. Add funds to your balance to complete this extension.
                        </p>
                        <Button variant="outline" size="sm" className="mt-2 gap-1 border-red-500/30 text-red-400 hover:bg-red-500/10 hover:text-red-300" onClick={() => { handleCancelExtend(); navigate('dashboard/payments') }}>
                          Go to Payments <ArrowRight className="size-3" />
                        </Button>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          )}

          {extendingSub && !extendPlan && (
            <div className="py-4">
              <div className="flex items-start gap-3 p-4 rounded-lg bg-amber-500/10 border border-amber-500/20">
                <AlertCircle className="size-5 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <p className="font-medium text-amber-400">Plan no longer available</p>
                  <p className="text-sm text-muted-foreground mt-1">
                    The plan &quot;{extendingSub.name}&quot; is no longer active and cannot be extended. You can purchase a new subscription instead.
                  </p>
                  <Button variant="outline" size="sm" className="mt-2 gap-1" onClick={() => { handleCancelExtend(); setPurchaseDialogOpen(true) }}>
                    Buy New Subscription <ArrowRight className="size-3" />
                  </Button>
                </div>
              </div>
            </div>
          )}

          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="ghost" onClick={handleCancelExtend}>Cancel</Button>
            {extendingSub && extendPlan && balance >= extendFinalPrice && (
              <Button className="gap-1.5" onClick={handleConfirmExtend}>
                <CalendarPlus className="size-4" />
                Confirm Extend — ৳{extendFinalPrice.toFixed(2)}
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── Plan Selection Dialog ── */}
      <Dialog open={purchaseDialogOpen} onOpenChange={setPurchaseDialogOpen}>
        <DialogContent className="sm:max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ShoppingCart className="size-5 text-primary" />
              Choose a Subscription Plan
            </DialogTitle>
            <DialogDescription>
              Select a plan that fits your needs. Browse by duration, then pick your plan.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-3">
            {DURATION_ORDER.map((dur) => {
              const plans = plansByDuration[dur]
              if (!plans || plans.length === 0) return null
              return (
                <div key={dur}>
                  <h3 className="text-sm font-medium text-muted-foreground mb-2">{plans[0].durationLabel}</h3>
                  <div className="grid gap-3">
                    {plans.map((plan) => {
                      const isSelected = selectedPlanId === plan.id
                      const baseTotal = calculateDevicePrice(plan.basePrice, plan.devicePricing, 1)
                      return (
                        <Card
                          key={plan.id}
                          className={`cursor-pointer transition-all group ${
                            isSelected
                              ? 'border-primary bg-primary/5 ring-1 ring-primary/30'
                              : 'border-border/50 hover:border-primary/50 hover:bg-primary/5'
                          }`}
                          onClick={() => handleSelectPlan(plan.id)}
                        >
                          <CardContent className="p-4 sm:p-5">
                            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                              <div className="space-y-2 flex-1">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <h3 className="font-semibold text-base">{plan.name}</h3>
                                  {plan.isFeatured && (
                                    <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30 gap-1 text-xs">
                                      <Star className="size-3" />
                                      Recommended
                                    </Badge>
                                  )}
                                  <Badge variant="outline" className="text-xs">
                                    <Clock className="size-3 mr-1" />
                                    {plan.durationLabel}
                                  </Badge>
                                </div>
                                <p className="text-sm text-muted-foreground">{plan.description}</p>
                                <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-muted-foreground">
                                  <span className="flex items-center gap-1">
                                    <Zap className="size-3.5 text-amber-400" />
                                    {plan.speed}
                                  </span>
                                  <span className="flex items-center gap-1">
                                    <Wifi className="size-3.5 text-teal-400" />
                                    <Badge
                                      variant="outline"
                                      className={`text-xs ${
                                        plan.bandwidthType === 'unlimited'
                                          ? 'border-emerald-500/30 text-emerald-400'
                                          : 'border-border text-muted-foreground'
                                      }`}
                                    >
                                      {plan.bandwidthLimit}
                                    </Badge>
                                  </span>
                                  <span className="flex items-center gap-1">
                                    <Globe className="size-3.5 text-emerald-400" />
                                    <span className="text-xs text-muted-foreground">Auto-assigned</span>
                                  </span>
                                </div>
                              </div>
                              <div className="flex items-center gap-4">
                                <div className="text-right">
                                  <div className="text-xl font-bold">৳{baseTotal.toFixed(2)}</div>
                                  <div className="text-xs text-muted-foreground">starting / 1 device</div>
                                </div>
                                <div className={`rounded-full p-2 transition-colors ${
                                  isSelected
                                    ? 'bg-primary text-primary-foreground'
                                    : 'bg-muted text-muted-foreground group-hover:bg-primary group-hover:text-primary-foreground'
                                }`}>
                                  {isSelected ? <Check className="size-4" /> : <ChevronRight className="size-4" />}
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      )
                    })}
                  </div>
                </div>
              )
            })}
          </div>

          {/* Device & Price Configuration */}
          {selectedPlan && (
            <div className="space-y-4 pt-4 border-t">
              <div className="flex items-center gap-2">
                <HardDrive className="size-4 text-primary" />
                <span className="font-medium text-sm">Select Number of Devices</span>
              </div>

              <div className="flex items-center gap-3 justify-center">
                {([1, 2, 3, 4, 5] as const).map((d) => {
                  const dPrice = calculateDevicePrice(selectedPlan.basePrice, selectedPlan.devicePricing, d)
                  const dSavings = getSavingsPercent(selectedPlan.basePrice, selectedPlan.devicePricing, d)
                  const isDevSelected = selectedDevices === d
                  return (
                    <button
                      key={d}
                      type="button"
                      onClick={() => setSelectedDevices(d)}
                      className={`flex flex-col items-center gap-1.5 rounded-xl px-3 py-3 transition-all border-2 min-w-[64px] ${
                        isDevSelected
                          ? 'border-primary bg-primary/10 text-primary shadow-sm'
                          : 'border-border/50 hover:border-primary/40 hover:bg-primary/5 text-muted-foreground'
                      }`}
                    >
                      <div className="flex items-center gap-0.5">
                        {Array.from({ length: d }).map((_, i) => (
                          <Monitor key={i} className={`size-3.5 ${isDevSelected ? 'text-primary' : 'text-muted-foreground'}`} />
                        ))}
                      </div>
                      <span className={`text-xs font-semibold ${isDevSelected ? 'text-primary' : 'text-muted-foreground'}`}>
                        {d} {d === 1 ? 'device' : 'devices'}
                      </span>
                      <span className="text-xs font-bold">৳{dPrice.toFixed(0)}</span>
                      {dSavings > 0 && (
                        <Badge className="text-[10px] px-1.5 py-0 h-4 bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
                          Save {dSavings}%
                        </Badge>
                      )}
                    </button>
                  )
                })}
              </div>

              <Card className="border-primary/20 bg-primary/5">
                <CardContent className="p-4">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold">{selectedPlan.name}</span>
                        <Badge variant="outline" className="text-xs">{selectedPlan.durationLabel}</Badge>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {selectedDevices} device{selectedDevices > 1 ? 's' : ''} · ৳{perDeviceCost.toFixed(2)} / device
                        {savingsPercent > 0 && (
                          <span className="ml-2 text-emerald-400">Saving {savingsPercent}%</span>
                        )}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold">৳{totalPrice.toFixed(2)}</div>
                      <div className="text-xs text-muted-foreground">total price</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Coupon */}
              <Card className="border-border/50">
                <CardContent className="p-4 space-y-3">
                  <div className="flex items-center gap-2">
                    <Tag className="size-4 text-primary" />
                    <span className="font-medium text-sm">Have a coupon code?</span>
                  </div>
                  {couponDiscount > 0 ? (
                    <div className="flex items-center justify-between rounded-lg border border-emerald-500/30 bg-emerald-500/10 px-3 py-2">
                      <div className="flex items-center gap-2">
                        <Tag className="size-4 text-emerald-400" />
                        <div>
                          <code className="font-mono text-sm font-bold text-emerald-400">{couponInput}</code>
                          <p className="text-xs text-emerald-300">Coupon applied! You save ৳{couponDiscount.toFixed(2)}</p>
                        </div>
                      </div>
                      <Button variant="ghost" size="icon" className="size-7 text-muted-foreground hover:text-red-400" onClick={handleRemoveCoupon}>
                        <X className="size-3.5" />
                      </Button>
                    </div>
                  ) : (
                    <div className="flex gap-2">
                      <Input
                        placeholder="Enter coupon code (try SAVE10)"
                        value={couponInput}
                        onChange={(e) => { setCouponInput(e.target.value.toUpperCase()); setCouponError(''); }}
                        className="font-mono"
                      />
                      <Button variant="outline" className="shrink-0 gap-1.5" onClick={handleApplyCoupon} disabled={!couponInput.trim()}>
                        <Tag className="size-3.5" />
                        Apply
                      </Button>
                    </div>
                  )}
                  {couponError && <p className="text-xs text-red-400">{couponError}</p>}
                </CardContent>
              </Card>

              <div className="flex items-center justify-between rounded-lg border p-3">
                <span className="font-semibold">Final Price</span>
                <span className="text-xl font-bold">৳{finalPrice.toFixed(2)}</span>
              </div>

              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Current Balance</span>
                <span className="font-semibold">৳{balance.toFixed(2)}</span>
              </div>

              {balance < finalPrice && (
                <div className="flex items-start gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/20">
                  <AlertCircle className="size-4 text-red-400 shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-red-400">Insufficient Balance</p>
                    <p className="text-xs text-muted-foreground mt-1">You need ৳{(finalPrice - balance).toFixed(2)} more.</p>
                  </div>
                </div>
              )}

              <DialogFooter className="gap-2 sm:gap-0 pt-2">
                <Button variant="outline" onClick={() => setPurchaseDialogOpen(false)}>Cancel</Button>
                {balance >= finalPrice ? (
                  <Button className="gap-1.5" onClick={handleProceedToCheckout} disabled={!selectedPlanId}>
                    Proceed to Checkout <ArrowRight className="size-4" />
                  </Button>
                ) : (
                  <Button className="gap-1.5" disabled>
                    Insufficient Balance
                  </Button>
                )}
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* ── Confirm Purchase Dialog ── */}
      <Dialog open={confirmDialogOpen} onOpenChange={(open) => { if (!open) handleCancelPurchase() }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Sparkles className="size-5 text-primary" />
              Confirm Purchase
            </DialogTitle>
            <DialogDescription>
              Review your order before completing the purchase
            </DialogDescription>
          </DialogHeader>

          {selectedPlan && (
            <div className="space-y-4">
              <Card className="border-primary/20 bg-primary/5">
                <CardContent className="p-4 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold">{selectedPlan.name}</span>
                    <Badge variant="outline">{selectedPlan.durationLabel}</Badge>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {selectedDevices} device{selectedDevices > 1 ? 's' : ''} · {selectedPlan.speed} · {selectedPlan.bandwidthLimit}
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between">
                    <span className="font-medium">Total</span>
                    <span className="text-xl font-bold">৳{finalPrice.toFixed(2)}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm text-muted-foreground">
                    <span>Balance after purchase</span>
                    <span className={balance - finalPrice < 0 ? 'text-red-400' : 'text-emerald-400'}>
                      ৳{(balance - finalPrice).toFixed(2)}
                    </span>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={handleBackToPlans}>Back</Button>
            <Button className="gap-1.5" onClick={handleConfirmPurchase}>
              <Check className="size-4" />
              Confirm Purchase
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
